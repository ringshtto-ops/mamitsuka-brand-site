import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Formwork from "./pages/Formwork";
import Team from "./pages/Team";
import Works from "./pages/Works";
import CorePlatform from "./pages/CorePlatform";
import Recruit from "./pages/Recruit";
import Company from "./pages/Company";
import Blog from "./pages/Blog";
import President from "./pages/President";
import Layout from "./components/Layout";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/formwork" component={Formwork} />
        <Route path="/team" component={Team} />
        <Route path="/works" component={Works} />
        <Route path="/core-platform" component={CorePlatform} />
        <Route path="/recruit" component={Recruit} />
        <Route path="/company" component={Company} />
        <Route path="/blog" component={Blog} />
        <Route path="/president" component={President} />
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
