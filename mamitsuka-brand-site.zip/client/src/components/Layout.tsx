/*
 * Design: Brutalist Cinematic
 * Layout: Fixed header with transparent-to-solid transition on scroll.
 * Footer: Minimal, concrete-toned with red thread accent.
 * Navigation: Clean, serif headings, minimal links.
 */
import { useState, useEffect, type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X } from "lucide-react";

const navItems = [
  { href: "/formwork", label: "型枠という仕事" },
  { href: "/team", label: "職人チーム" },
  { href: "/works", label: "施工実績" },
  { href: "/core-platform", label: "CORE PLATFORM" },
  { href: "/recruit", label: "採用情報" },
  { href: "/president", label: "まみ社長とは" },
  { href: "/company", label: "会社情報" },
  { href: "/blog", label: "ブログ" },
];

function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location]);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-[oklch(0.96_0.005_80/0.95)] backdrop-blur-md shadow-sm"
          : "bg-transparent"
      }`}
    >
      <div className="container flex items-center justify-between h-16 lg:h-20">
        <Link href="/" className="flex items-center gap-3 group">
          <span className="font-serif-jp text-lg lg:text-xl font-bold tracking-wider text-foreground">
            MAMITSUKA
          </span>
          <span className="hidden sm:block w-px h-5 bg-mamitsuka-red" />
          <span className="hidden sm:block font-sans-jp text-[11px] tracking-[0.2em] text-muted-foreground">
            馬見塚建設
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden xl:flex items-center gap-6">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`font-sans-jp text-[13px] tracking-[0.08em] transition-colors duration-300 hover:text-mamitsuka-red ${
                location === item.href
                  ? "text-mamitsuka-red"
                  : "text-foreground/70"
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Mobile Menu Toggle */}
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="xl:hidden p-2 text-foreground"
          aria-label="メニュー"
        >
          {mobileOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="xl:hidden bg-[oklch(0.96_0.005_80/0.98)] backdrop-blur-md border-t border-border"
          >
            <nav className="container py-6 flex flex-col gap-4">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`font-sans-jp text-sm tracking-[0.08em] py-2 transition-colors ${
                    location === item.href
                      ? "text-mamitsuka-red"
                      : "text-foreground/70"
                  }`}
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

function Footer() {
  return (
    <footer className="bg-mamitsuka-dark text-white/80">
      {/* Red thread accent */}
      <div className="w-full h-[2px] bg-mamitsuka-red" />

      <div className="container py-16 lg:py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-8">
          {/* Brand */}
          <div className="lg:col-span-1">
            <h3 className="font-serif-jp text-xl font-bold text-white tracking-wider mb-4">
              MAMITSUKA
            </h3>
            <p className="font-sans-jp text-xs text-white/50 leading-relaxed mb-6">
              株式会社馬見塚建設
              <br />
              型枠工事専門
            </p>
            <div className="red-thread mb-6" />
            <p className="font-sans-jp text-xs text-white/40 leading-loose">
              〒480-1147
              <br />
              愛知県長久手市市が洞1丁目501番地901
              <br />
              TEL: 0561-73-6537
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="font-sans-jp text-xs tracking-[0.2em] text-white/40 uppercase mb-6">
              Navigation
            </h4>
            <nav className="flex flex-col gap-3">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="font-sans-jp text-sm text-white/60 hover:text-mamitsuka-red transition-colors"
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>

          {/* SNS */}
          <div>
            <h4 className="font-sans-jp text-xs tracking-[0.2em] text-white/40 uppercase mb-6">
              Social
            </h4>
            <nav className="flex flex-col gap-3">
              <a
                href="https://note.com/mamitsuka"
                target="_blank"
                rel="noopener noreferrer"
                className="font-sans-jp text-sm text-white/60 hover:text-mamitsuka-red transition-colors"
              >
                note
              </a>
              <a
                href="https://www.youtube.com/@kensetu"
                target="_blank"
                rel="noopener noreferrer"
                className="font-sans-jp text-sm text-white/60 hover:text-mamitsuka-red transition-colors"
              >
                YouTube
              </a>
              <a
                href="#"
                className="font-sans-jp text-sm text-white/60 hover:text-mamitsuka-red transition-colors"
              >
                Instagram
              </a>
              <a
                href="#"
                className="font-sans-jp text-sm text-white/60 hover:text-mamitsuka-red transition-colors"
              >
                Facebook
              </a>
            </nav>
          </div>

          {/* Recruit CTA */}
          <div>
            <h4 className="font-sans-jp text-xs tracking-[0.2em] text-white/40 uppercase mb-6">
              Join Us
            </h4>
            <p className="font-sans-jp text-sm text-white/60 leading-relaxed mb-6">
              型枠という仕事で、
              <br />
              未来の街をつくる仲間を
              <br />
              探しています。
            </p>
            <Link
              href="/recruit"
              className="inline-block font-sans-jp text-xs tracking-[0.15em] border border-mamitsuka-red text-mamitsuka-red px-6 py-3 hover:bg-mamitsuka-red hover:text-white transition-all duration-300"
            >
              採用情報を見る
            </Link>
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-16 pt-8 border-t border-white/10 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="font-sans-jp text-[11px] text-white/30">
            &copy; {new Date().getFullYear()} 株式会社馬見塚建設 All Rights Reserved.
          </p>
          <p className="font-display text-[11px] text-white/20 italic tracking-wider">
            The Framework of Tomorrow
          </p>
        </div>
      </div>
    </footer>
  );
}

function ScrollToTop() {
  const [location] = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);
  return null;
}

export default function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col concrete-texture">
      <ScrollToTop />
      <Header />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}
