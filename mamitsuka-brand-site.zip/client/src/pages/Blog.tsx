/*
 * Design: Brutalist Cinematic
 * Page: ブログ / コラム (Blog)
 * SEO・LLM対策の記事ページ。noteやYouTubeへの導線。
 * 社長が後から記事を追加できるよう、データ構造を明確にする。
 */
import SectionWrapper from "@/components/SectionWrapper";
import { ArrowRight, ExternalLink } from "lucide-react";

const articles = [
  {
    date: "2026.03",
    tag: "型枠コラム",
    title: "型枠大工はコンクリートを流さない",
    desc: "「型枠大工」と聞くと、コンクリートを扱う仕事だと思われがちだ。しかし実際は違う。型枠大工の仕事は、コンクリートを流し込む「前」にある。",
    link: "https://note.com/mamitsuka",
    external: true,
  },
  {
    date: "2026.03",
    tag: "YouTube",
    title: "型枠アンセム「FORMED」MV公開",
    desc: "型枠の仕事を音楽で表現したミュージックビデオ。職人の誇りと現場の緊張感を、映像と音楽で伝える。",
    link: "https://www.youtube.com/@kensetu",
    external: true,
  },
  {
    date: "2026.02",
    tag: "お知らせ",
    title: "2026年度 新卒採用ページ公開",
    desc: "本気で技術を磨きたい方へ。馬見塚建設の新卒採用を開始しました。経験不問、覚悟のある方を歓迎します。",
    link: "/recruit",
    external: false,
  },
  {
    date: "2026.02",
    tag: "型枠コラム",
    title: "型枠の精度が建物の品質を決める理由",
    desc: "型枠の精度は1mm単位。足元のズレ、出隅のズレ、垂直のズレ。わずかな狂いが建物全体に影響する、その理由を解説。",
    link: "https://note.com/mamitsuka",
    external: true,
  },
  {
    date: "2026.01",
    tag: "CORE PLATFORM",
    title: "MAMITSUKA CORE PLATFORM構想を発表",
    desc: "職人の経験をデータ化し、AIで次世代へ繋ぐ。馬見塚建設が目指す、建設業の未来のプラットフォーム構想。",
    link: "https://note.com/mamitsuka",
    external: true,
  },
  {
    date: "2026.01",
    tag: "型枠コラム",
    title: "段取り八分 ― 型枠大工の仕事の本質",
    desc: "現場が始まる前に勝負は決まっている。図面を読み、材料を拾い、工程を組む。型枠大工にとっての「段取り」とは何か。",
    link: "https://note.com/mamitsuka",
    external: true,
  },
];

export default function Blog() {
  return (
    <div>
      {/* Hero */}
      <section className="relative h-[40vh] lg:h-[50vh] overflow-hidden bg-mamitsuka-dark">
        <div className="relative h-full flex flex-col justify-end pb-16 lg:pb-24 container">
          <SectionWrapper>
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-4">
              Blog & Column
            </p>
            <h1 className="font-serif-jp text-white text-3xl lg:text-6xl font-bold leading-[1.3]">
              ブログ / コラム
            </h1>
          </SectionWrapper>
        </div>
      </section>

      {/* Articles */}
      <section className="py-24 lg:py-36">
        <SectionWrapper className="container">
          <div className="max-w-3xl mx-auto">
            <div className="space-y-0 divide-y divide-border">
              {articles.map((article, i) => (
                <SectionWrapper key={i} delay={i * 0.05}>
                  {article.external ? (
                    <a
                      href={article.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block py-8 group"
                    >
                      <div className="flex items-center gap-3 mb-3">
                        <time className="font-display text-xs text-muted-foreground tracking-wider">
                          {article.date}
                        </time>
                        <span className="font-sans-jp text-[10px] tracking-wider px-2 py-0.5 border border-mamitsuka-red/30 text-mamitsuka-red">
                          {article.tag}
                        </span>
                      </div>
                      <h2 className="font-serif-jp text-lg lg:text-xl font-bold mb-3 group-hover:text-mamitsuka-red transition-colors flex items-center gap-2">
                        {article.title}
                        <ExternalLink size={14} className="text-muted-foreground" />
                      </h2>
                      <p className="font-sans-jp text-muted-foreground text-sm leading-[2]">
                        {article.desc}
                      </p>
                    </a>
                  ) : (
                    <a href={article.link} className="block py-8 group">
                      <div className="flex items-center gap-3 mb-3">
                        <time className="font-display text-xs text-muted-foreground tracking-wider">
                          {article.date}
                        </time>
                        <span className="font-sans-jp text-[10px] tracking-wider px-2 py-0.5 border border-mamitsuka-red/30 text-mamitsuka-red">
                          {article.tag}
                        </span>
                      </div>
                      <h2 className="font-serif-jp text-lg lg:text-xl font-bold mb-3 group-hover:text-mamitsuka-red transition-colors">
                        {article.title}
                      </h2>
                      <p className="font-sans-jp text-muted-foreground text-sm leading-[2]">
                        {article.desc}
                      </p>
                    </a>
                  )}
                </SectionWrapper>
              ))}
            </div>
          </div>
        </SectionWrapper>
      </section>

      {/* External Links */}
      <section className="py-24 lg:py-36 bg-secondary/50">
        <SectionWrapper className="container text-center">
          <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6">
            More Content
          </p>
          <h2 className="font-serif-jp text-2xl lg:text-4xl font-bold mb-12">
            もっと読む・観る
          </h2>

          <div className="flex flex-wrap justify-center gap-6">
            <a
              href="https://note.com/mamitsuka"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 font-sans-jp text-sm tracking-wider border border-border px-8 py-4 hover:border-mamitsuka-red hover:text-mamitsuka-red transition-all duration-300"
            >
              noteで記事を読む
              <ArrowRight size={16} />
            </a>
            <a
              href="https://www.youtube.com/@kensetu"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 font-sans-jp text-sm tracking-wider border border-border px-8 py-4 hover:border-mamitsuka-red hover:text-mamitsuka-red transition-all duration-300"
            >
              YouTubeで動画を観る
              <ArrowRight size={16} />
            </a>
          </div>
        </SectionWrapper>
      </section>
    </div>
  );
}
