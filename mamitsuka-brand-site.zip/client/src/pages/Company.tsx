/*
 * Design: Brutalist Cinematic
 * Page: 会社情報 (Company)
 * 信用を高める会社概要。SDGsも含む。
 */
import SectionWrapper from "@/components/SectionWrapper";
import { Link } from "wouter";
import { ArrowRight, MapPin, Phone, Globe, Building } from "lucide-react";

export default function Company() {
  return (
    <div>
      {/* Hero */}
      <section className="relative h-[40vh] lg:h-[50vh] overflow-hidden bg-mamitsuka-dark">
        <div className="relative h-full flex flex-col justify-end pb-16 lg:pb-24 container">
          <SectionWrapper>
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-4">
              Company
            </p>
            <h1 className="font-serif-jp text-white text-3xl lg:text-6xl font-bold leading-[1.3]">
              会社情報
            </h1>
          </SectionWrapper>
        </div>
      </section>

      {/* Company Overview */}
      <section className="py-24 lg:py-36">
        <SectionWrapper className="container">
          <div className="max-w-3xl mx-auto">
            <h2 className="font-serif-jp text-2xl lg:text-4xl font-bold leading-[1.5] mb-8 text-center">
              街の骨格をつくる会社。
            </h2>
            <div className="red-thread mx-auto mb-10" />
            <p className="font-sans-jp text-muted-foreground leading-[2.2] text-sm lg:text-base mb-12 text-center">
              株式会社馬見塚建設は、愛知県を拠点に型枠工事を専門とする建設会社です。在来型枠とラス型枠の両方に対応し、マンション・学校・物流施設・商業施設など、幅広い建築物の型枠工事を手がけています。
            </p>

            <div className="border border-border divide-y divide-border">
              {[
                { label: "会社名", value: "株式会社馬見塚建設" },
                { label: "代表者", value: "代表取締役" },
                { label: "事業内容", value: "型枠工事（在来型枠・ラス型枠）" },
                { label: "所在地", value: "〒480-1147 愛知県長久手市市が洞1丁目501番地901" },
                { label: "電話番号", value: "0561-73-6537" },
                { label: "設立", value: "―" },
                { label: "施工エリア", value: "愛知県（名古屋エリア中心）" },
                { label: "対応工法", value: "在来型枠工法、ラス型枠工法" },
                { label: "主な施工物件", value: "マンション、学校、物流施設、商業施設 等" },
              ].map((item) => (
                <div key={item.label} className="flex flex-col sm:flex-row p-4 lg:p-6">
                  <span className="font-sans-jp text-sm font-medium w-40 flex-shrink-0 mb-1 sm:mb-0">
                    {item.label}
                  </span>
                  <span className="font-sans-jp text-sm text-muted-foreground">{item.value}</span>
                </div>
              ))}
            </div>
          </div>
        </SectionWrapper>
      </section>

      {/* Access */}
      <section className="py-24 lg:py-36 bg-secondary/50">
        <SectionWrapper className="container">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6">
              Access
            </p>
            <h2 className="font-serif-jp text-2xl lg:text-4xl font-bold">
              アクセス
            </h2>
          </div>

          <div className="max-w-3xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <MapPin className="text-mamitsuka-red flex-shrink-0 mt-1" size={20} />
                <div>
                  <h3 className="font-sans-jp text-sm font-medium mb-1">所在地</h3>
                  <p className="font-sans-jp text-muted-foreground text-sm leading-relaxed">
                    〒480-1147<br />
                    愛知県長久手市市が洞1丁目501番地901
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <Phone className="text-mamitsuka-red flex-shrink-0 mt-1" size={20} />
                <div>
                  <h3 className="font-sans-jp text-sm font-medium mb-1">電話番号</h3>
                  <p className="font-sans-jp text-muted-foreground text-sm">0561-73-6537</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <Globe className="text-mamitsuka-red flex-shrink-0 mt-1" size={20} />
                <div>
                  <h3 className="font-sans-jp text-sm font-medium mb-1">Web</h3>
                  <p className="font-sans-jp text-muted-foreground text-sm">www.mamituka.co.jp</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <Building className="text-mamitsuka-red flex-shrink-0 mt-1" size={20} />
                <div>
                  <h3 className="font-sans-jp text-sm font-medium mb-1">施工エリア</h3>
                  <p className="font-sans-jp text-muted-foreground text-sm">愛知県内（名古屋エリア中心）</p>
                </div>
              </div>
            </div>
            <div className="bg-muted h-64 lg:h-auto flex items-center justify-center border border-border">
              <p className="font-sans-jp text-muted-foreground text-sm">地図を表示</p>
            </div>
          </div>
        </SectionWrapper>
      </section>

      {/* SDGs */}
      <section className="py-24 lg:py-36">
        <SectionWrapper className="container">
          <div className="max-w-3xl mx-auto">
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6 text-center">
              SDGs
            </p>
            <h2 className="font-serif-jp text-2xl lg:text-4xl font-bold leading-[1.4] mb-8 text-center">
              持続可能な社会への取り組み
            </h2>
            <div className="red-thread mx-auto mb-10" />
            <p className="font-sans-jp text-muted-foreground leading-[2.2] text-sm lg:text-base mb-12 text-center">
              馬見塚建設は、建設業を通じて持続可能な社会の実現に貢献します。
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                {
                  goal: "4. 質の高い教育をみんなに",
                  desc: "若手職人への技術教育、MAMITSUKA CORE PLATFORMによる技術継承を通じて、建設業の人材育成に貢献します。",
                },
                {
                  goal: "8. 働きがいも経済成長も",
                  desc: "職人が誇りを持って働ける環境づくりと、建設業の生産性向上に取り組みます。",
                },
                {
                  goal: "9. 産業と技術革新の基盤をつくろう",
                  desc: "AIやデータ活用による建設業のDX推進を通じて、産業の革新に貢献します。",
                },
                {
                  goal: "11. 住み続けられるまちづくりを",
                  desc: "高品質な型枠工事を通じて、安全で持続可能な建築物の建設に貢献します。",
                },
              ].map((item) => (
                <div key={item.goal} className="border border-border p-6 lg:p-8">
                  <h3 className="font-sans-jp text-sm font-bold text-mamitsuka-red mb-3">{item.goal}</h3>
                  <p className="font-sans-jp text-muted-foreground text-sm leading-[2]">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </SectionWrapper>
      </section>

      {/* SNS Links */}
      <section className="py-24 lg:py-36 bg-mamitsuka-dark">
        <SectionWrapper className="container text-center">
          <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6">
            Follow Us
          </p>
          <h2 className="font-serif-jp text-white text-2xl lg:text-4xl font-bold mb-12">
            SNSで最新情報をチェック
          </h2>

          <div className="flex flex-wrap justify-center gap-6">
            {[
              { name: "note", url: "https://note.com/mamitsuka" },
              { name: "YouTube", url: "https://www.youtube.com/@kensetu" },
              { name: "Instagram", url: "#" },
              { name: "Facebook", url: "#" },
            ].map((sns) => (
              <a
                key={sns.name}
                href={sns.url}
                target="_blank"
                rel="noopener noreferrer"
                className="font-sans-jp text-sm tracking-wider border border-white/20 text-white/60 px-8 py-4 hover:border-mamitsuka-red hover:text-mamitsuka-red transition-all duration-300"
              >
                {sns.name}
              </a>
            ))}
          </div>
        </SectionWrapper>
      </section>

      {/* CTA */}
      <section className="py-24 lg:py-36">
        <SectionWrapper className="container text-center">
          <h2 className="font-serif-jp text-2xl lg:text-4xl font-bold leading-[1.4] mb-6">
            お問い合わせ
          </h2>
          <div className="red-thread mx-auto mb-8" />
          <p className="font-sans-jp text-muted-foreground text-sm lg:text-base leading-relaxed max-w-xl mx-auto mb-10">
            型枠工事のご依頼・ご相談、採用に関するお問い合わせは、お気軽にご連絡ください。
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="tel:0561-73-6537"
              className="inline-flex items-center justify-center gap-3 font-sans-jp text-sm tracking-[0.1em] bg-mamitsuka-red text-white px-8 py-4 hover:bg-mamitsuka-red/90 transition-all duration-300"
            >
              電話で問い合わせる
            </a>
            <Link
              href="/recruit"
              className="inline-flex items-center justify-center gap-3 font-sans-jp text-sm tracking-[0.1em] border border-mamitsuka-red text-mamitsuka-red px-8 py-4 hover:bg-mamitsuka-red hover:text-white transition-all duration-300"
            >
              採用情報を見る
              <ArrowRight size={16} />
            </Link>
          </div>
        </SectionWrapper>
      </section>
    </div>
  );
}
