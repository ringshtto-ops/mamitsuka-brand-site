/*
 * Design: Brutalist Cinematic
 * Page: MAMITSUKA CORE PLATFORM
 * 「ただの施工会社ではなく、建設業の未来を考える会社」を伝える。
 * 職人 × テクノロジー の構想を提示。
 */
import SectionWrapper from "@/components/SectionWrapper";
import { Link } from "wouter";
import { ArrowRight, Database, Brain, Layers, Zap } from "lucide-react";

const CORE_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/core-platform-future-mjbCwZZAuXeTRsVD2BvFxq.webp";

export default function CorePlatform() {
  return (
    <div>
      {/* Hero */}
      <section className="relative h-[60vh] lg:h-[70vh] overflow-hidden">
        <div className="absolute inset-0">
          <img src={CORE_IMG} alt="MAMITSUKA CORE PLATFORM" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-black/30" />
        </div>
        <div className="relative h-full flex flex-col justify-end pb-16 lg:pb-24 container">
          <SectionWrapper>
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-4">
              MAMITSUKA CORE PLATFORM
            </p>
            <h1 className="font-serif-jp text-white text-3xl lg:text-6xl font-bold leading-[1.3]">
              職人の勘を、
              <br />
              世界の共有知へ。
            </h1>
          </SectionWrapper>
        </div>
        <div className="absolute top-0 left-0 right-0 h-[3vh] bg-black/80" />
      </section>

      {/* Vision */}
      <section className="py-24 lg:py-36">
        <SectionWrapper className="container">
          <div className="max-w-3xl mx-auto">
            <h2 className="font-serif-jp text-2xl lg:text-4xl font-bold leading-[1.5] mb-8 text-center">
              経験を、データという遺産へ。
            </h2>
            <div className="red-thread mx-auto mb-10" />
            <p className="font-sans-jp text-muted-foreground leading-[2.2] text-sm lg:text-base mb-6">
              型枠の技術は、図面だけでは伝わらない。現場で積み重ねた判断や感覚がある。「この納まりはこう組む」「この形状にはこの段取りが効く」。そうした「名もなき経験」は、職人の頭の中にしか存在しない。
            </p>
            <p className="font-sans-jp text-muted-foreground leading-[2.2] text-sm lg:text-base mb-6">
              MAMITSUKA CORE PLATFORMは、その経験をデータ化し、AIと共に次世代へ繋ぐための構想です。単なるDXではない。職人の魂を未来に残すための、私たちの挑戦です。
            </p>
            <p className="font-sans-jp text-foreground font-medium leading-[2.2] text-sm lg:text-base">
              馬見塚建設は、施工会社を超え、建設業の未来を創るプラットフォームへと進化します。
            </p>
          </div>
        </SectionWrapper>
      </section>

      {/* Four Pillars */}
      <section className="py-24 lg:py-36 bg-mamitsuka-dark">
        <SectionWrapper className="container">
          <div className="text-center mb-16">
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6">
              Four Pillars
            </p>
            <h2 className="font-serif-jp text-white text-3xl lg:text-5xl font-bold">
              4つの柱
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {[
              {
                icon: Database,
                title: "職人経験のデータ化",
                desc: "現場での判断、段取りのノウハウ、施工のコツ。職人の頭の中にある「暗黙知」を、体系的にデータとして蓄積します。",
              },
              {
                icon: Brain,
                title: "AIによる技術継承",
                desc: "蓄積されたデータをAIが学習し、若手職人の教育や現場の意思決定をサポート。経験年数に関わらず、最適な判断を導きます。",
              },
              {
                icon: Layers,
                title: "施工ナレッジの蓄積",
                desc: "過去の施工実績、トラブル対応、品質管理のノウハウを一元管理。現場ごとの知見が、会社全体の財産になります。",
              },
              {
                icon: Zap,
                title: "次世代建設プラットフォーム",
                desc: "型枠工事に留まらず、建設業全体の生産性向上に貢献するプラットフォームの構築を目指します。",
              },
            ].map((pillar, i) => (
              <SectionWrapper key={pillar.title} delay={i * 0.15}>
                <div className="border border-white/10 p-8 lg:p-10 hover:border-mamitsuka-red/30 transition-all duration-500">
                  <pillar.icon className="text-mamitsuka-red mb-6" size={36} strokeWidth={1.5} />
                  <h3 className="font-serif-jp text-white text-xl font-bold mb-4">{pillar.title}</h3>
                  <p className="font-sans-jp text-white/50 text-sm leading-[2]">{pillar.desc}</p>
                </div>
              </SectionWrapper>
            ))}
          </div>
        </SectionWrapper>
      </section>

      {/* AI Characters */}
      <section className="py-24 lg:py-36">
        <SectionWrapper className="container">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6">
              AI Assistants
            </p>
            <h2 className="font-serif-jp text-2xl lg:text-4xl font-bold leading-[1.4] mb-8">
              AIが、型枠の知識を届ける。
            </h2>
            <div className="red-thread mx-auto mb-8" />
            <p className="font-sans-jp text-muted-foreground leading-[2] text-sm lg:text-base">
              MAMITSUKA CORE PLATFORMから生まれた2つのAIキャラクターが、型枠の世界をわかりやすく伝えます。
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto">
            <div className="border border-border p-8 text-center">
              <div className="w-20 h-20 mx-auto mb-6 bg-mamitsuka-dark rounded-full flex items-center justify-center">
                <span className="font-serif-jp text-2xl text-mamitsuka-red font-bold">片</span>
              </div>
              <h3 className="font-serif-jp text-xl font-bold mb-2">かたやん</h3>
              <p className="font-sans-jp text-mamitsuka-red text-xs tracking-wider mb-4">
                経営戦略AI参謀
              </p>
              <p className="font-sans-jp text-muted-foreground text-sm leading-[2]">
                型枠技術の言語化、経営戦略、DX推進をサポートするAI。社長の右腕として、具体的な戦略と次の一手を提示します。
              </p>
            </div>

            <div className="border border-border p-8 text-center">
              <div className="w-20 h-20 mx-auto mb-6 bg-mamitsuka-dark rounded-full flex items-center justify-center">
                <span className="font-serif-jp text-2xl text-mamitsuka-red font-bold">紅</span>
              </div>
              <h3 className="font-serif-jp text-xl font-bold mb-2">べに子</h3>
              <p className="font-sans-jp text-mamitsuka-red text-xs tracking-wider mb-4">
                現場AIアシスタント
              </p>
              <p className="font-sans-jp text-muted-foreground text-sm leading-[2]">
                型枠施工、若手教育、安全管理をサポートするAI。現場で使える知識を、わかりやすい言葉で届けます。
              </p>
            </div>
          </div>
        </SectionWrapper>
      </section>

      {/* Roadmap */}
      <section className="py-24 lg:py-36 bg-secondary/50">
        <SectionWrapper className="container">
          <div className="max-w-3xl mx-auto">
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6 text-center">
              Roadmap
            </p>
            <h2 className="font-serif-jp text-2xl lg:text-4xl font-bold leading-[1.4] mb-12 text-center">
              未来への道筋
            </h2>

            <div className="space-y-0">
              {[
                { phase: "Phase 1", title: "知識の蓄積", desc: "職人の経験やノウハウをデータとして記録・蓄積する基盤を構築。noteやYouTubeでの発信を通じて、型枠技術の言語化を推進。", status: "進行中" },
                { phase: "Phase 2", title: "AIの導入", desc: "蓄積されたデータを基に、AIによる技術継承システムを開発。若手教育や現場判断のサポートを実現。", status: "準備中" },
                { phase: "Phase 3", title: "プラットフォーム化", desc: "馬見塚建設の枠を超え、建設業界全体で活用できるナレッジプラットフォームとして展開。", status: "構想中" },
              ].map((item, i) => (
                <div key={i} className="flex gap-6 lg:gap-10">
                  <div className="flex flex-col items-center">
                    <div className={`w-4 h-4 rounded-full flex-shrink-0 ${item.status === "進行中" ? "bg-mamitsuka-red" : "border-2 border-mamitsuka-red/30"}`} />
                    {i < 2 && <div className="w-px flex-1 bg-border mt-0" />}
                  </div>
                  <div className="pb-12">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="font-display text-sm text-mamitsuka-red font-bold">{item.phase}</span>
                      <span className="font-sans-jp text-[10px] tracking-wider px-2 py-0.5 border border-mamitsuka-red/30 text-mamitsuka-red">
                        {item.status}
                      </span>
                    </div>
                    <h3 className="font-serif-jp text-lg font-bold mb-3">{item.title}</h3>
                    <p className="font-sans-jp text-muted-foreground text-sm leading-[2]">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </SectionWrapper>
      </section>

      {/* CTA */}
      <section className="py-24 lg:py-36">
        <SectionWrapper className="container text-center">
          <h2 className="font-serif-jp text-2xl lg:text-4xl font-bold leading-[1.4] mb-6">
            この構想に、共感するなら。
          </h2>
          <div className="red-thread mx-auto mb-8" />
          <p className="font-sans-jp text-muted-foreground text-sm lg:text-base leading-relaxed max-w-xl mx-auto mb-10">
            型枠の技術を未来に残す。その志に共感してくれる仲間を、私たちは探しています。
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/recruit"
              className="inline-flex items-center justify-center gap-3 font-sans-jp text-sm tracking-[0.1em] bg-mamitsuka-red text-white px-8 py-4 hover:bg-mamitsuka-red/90 transition-all duration-300"
            >
              採用情報を見る
              <ArrowRight size={16} />
            </Link>
            <a
              href="https://note.com/mamitsuka"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-3 font-sans-jp text-sm tracking-[0.1em] border border-mamitsuka-red text-mamitsuka-red px-8 py-4 hover:bg-mamitsuka-red hover:text-white transition-all duration-300"
            >
              noteで詳しく読む
              <ArrowRight size={16} />
            </a>
          </div>
        </SectionWrapper>
      </section>
    </div>
  );
}
