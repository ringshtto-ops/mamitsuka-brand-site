/*
 * Design: Brutalist Cinematic
 * Page: 型枠という仕事 (The Art of Formwork)
 * ストーリーテリング形式で型枠の魅力、精度、段取り、達成感を伝える。
 * SEO: 「型枠とは」「型枠大工とは」「型枠工事とは」をカバー。
 */
import SectionWrapper from "@/components/SectionWrapper";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";

const PRECISION_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/precision-scale-cinematic-LwrPvtZvMdZ4xAFXQuYdpp.webp";
const HERO_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/hero-construction-site-n9gqUQyPddN28AGxjbg4Bj.webp";

export default function Formwork() {
  return (
    <div>
      {/* Hero */}
      <section className="relative h-[60vh] lg:h-[70vh] overflow-hidden">
        <div className="absolute inset-0">
          <img src={PRECISION_IMG} alt="型枠の精度" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/70" />
        </div>
        <div className="relative h-full flex flex-col justify-end pb-16 lg:pb-24 container">
          <SectionWrapper>
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-4">
              The Art of Formwork
            </p>
            <h1 className="font-serif-jp text-white text-3xl lg:text-6xl font-bold leading-[1.3]">
              型枠という仕事。
            </h1>
          </SectionWrapper>
        </div>
        <div className="absolute top-0 left-0 right-0 h-[3vh] bg-black/80" />
      </section>

      {/* Introduction */}
      <section className="py-24 lg:py-36">
        <SectionWrapper className="container">
          <div className="max-w-3xl mx-auto">
            <h2 className="font-serif-jp text-2xl lg:text-4xl font-bold leading-[1.5] mb-8 text-center">
              形なきものに、形を与える。
            </h2>
            <div className="red-thread mx-auto mb-10" />
            <p className="font-sans-jp text-muted-foreground leading-[2.2] text-sm lg:text-base mb-6">
              コンクリートは、流し込んだだけでは建物にならない。壁の厚さ、柱の太さ、梁の位置。すべての「形」を正確に決めるのが、型枠という仕事だ。
            </p>
            <p className="font-sans-jp text-muted-foreground leading-[2.2] text-sm lg:text-base mb-6">
              型枠大工は、設計図面を読み解き、木材やパネルを使って「型」をつくる。その型にコンクリートを流し込み、固まったら型を外す。現れるのは、設計通りの美しいコンクリートの壁や柱。つまり型枠とは、建物の骨格そのものを創る仕事である。
            </p>
            <p className="font-sans-jp text-foreground font-medium leading-[2.2] text-sm lg:text-base">
              マンション、学校、病院、物流施設。あなたが毎日目にする建物の骨格は、型枠大工の手によって形づくられている。
            </p>
          </div>
        </SectionWrapper>
      </section>

      {/* 1mm Precision */}
      <section className="py-24 lg:py-36 bg-mamitsuka-dark">
        <SectionWrapper className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6">
                Precision
              </p>
              <h2 className="font-serif-jp text-white text-3xl lg:text-5xl font-bold leading-[1.4] mb-8">
                1mmのプライド。
              </h2>
              <div className="red-thread mb-8" />
              <p className="font-sans-jp text-white/60 leading-[2.2] text-sm lg:text-base mb-6">
                型枠の精度は、1mm単位で管理される。足元のズレ、出隅のズレ、垂直のズレ。わずかな狂いが、建物全体の品質を左右する。
              </p>
              <p className="font-sans-jp text-white/60 leading-[2.2] text-sm lg:text-base mb-6">
                コンクリートは一度固まれば、やり直しがきかない。だからこそ、型枠を組む段階で完璧を求める。コンベックスで測り、下げ振りで垂直を確認し、何度も何度も精度を追い込む。
              </p>
              <p className="font-sans-jp text-white/80 font-medium leading-[2.2] text-sm lg:text-base">
                その1mmへのこだわりが、100年先の安全を支えている。
              </p>
            </div>
            <div className="relative">
              <div className="bg-white/5 border border-white/10 p-8 lg:p-12">
                <div className="space-y-8">
                  {[
                    { label: "垂直精度", value: "±5mm", desc: "下げ振りによる垂直管理" },
                    { label: "水平精度", value: "±5mm", desc: "レベルによる水平管理" },
                    { label: "寸法精度", value: "±2mm", desc: "コンベックスによる寸法管理" },
                  ].map((item) => (
                    <div key={item.label} className="border-b border-white/10 pb-6 last:border-0 last:pb-0">
                      <div className="flex items-baseline justify-between mb-2">
                        <span className="font-sans-jp text-white/50 text-xs tracking-wider">{item.label}</span>
                        <span className="font-display text-mamitsuka-red text-2xl lg:text-3xl font-bold">{item.value}</span>
                      </div>
                      <p className="font-sans-jp text-white/30 text-xs">{item.desc}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </SectionWrapper>
      </section>

      {/* Dandori */}
      <section className="py-24 lg:py-36">
        <SectionWrapper className="container">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6">
              Planning
            </p>
            <h2 className="font-serif-jp text-3xl lg:text-5xl font-bold leading-[1.4] mb-8">
              段取りがすべて。
            </h2>
            <div className="red-thread mx-auto mb-8" />
            <p className="font-sans-jp text-muted-foreground leading-[2.2] text-sm lg:text-base">
              現場が始まる前に、勝負は決まっている。図面を読み、材料を拾い出し、工程を組む。頭の中で建物を一度完成させてから、初めて現場に立つ。それが型枠大工の「段取り」だ。
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { step: "01", title: "拾い出し", desc: "図面から必要な材料の種類と数量を正確に読み取る。" },
              { step: "02", title: "加工", desc: "木材やパネルを寸法通りに切断し、型枠の部材をつくる。" },
              { step: "03", title: "建込み", desc: "加工した部材を現場で組み立て、型枠を建てていく。" },
              { step: "04", title: "締固め・脱型", desc: "コンクリート打設後、養生期間を経て型枠を解体する。" },
            ].map((item) => (
              <SectionWrapper key={item.step} delay={Number(item.step) * 0.1}>
                <div className="border border-border p-6 lg:p-8 hover:border-mamitsuka-red/30 transition-all duration-500">
                  <span className="font-display text-4xl font-bold text-mamitsuka-red/20 block mb-4">
                    {item.step}
                  </span>
                  <h3 className="font-serif-jp text-lg font-bold mb-3">{item.title}</h3>
                  <p className="font-sans-jp text-muted-foreground text-sm leading-relaxed">{item.desc}</p>
                </div>
              </SectionWrapper>
            ))}
          </div>
        </SectionWrapper>
      </section>

      {/* Achievement */}
      <section className="relative py-24 lg:py-36 overflow-hidden">
        <div className="absolute inset-0">
          <img src={HERO_IMG} alt="現場" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-black/70" />
        </div>
        <SectionWrapper className="container relative z-10">
          <div className="max-w-3xl">
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6">
              Achievement
            </p>
            <h2 className="font-serif-jp text-white text-3xl lg:text-5xl font-bold leading-[1.4] mb-8">
              型枠を外した瞬間の、
              <br />
              あの達成感。
            </h2>
            <div className="red-thread mb-8" />
            <p className="font-sans-jp text-white/60 leading-[2.2] text-sm lg:text-base mb-6">
              コンクリートが固まり、型枠を外す。その瞬間に現れる、美しいコンクリートの肌。自分たちが組み上げた「型」が、そのまま建物の形になっている。
            </p>
            <p className="font-sans-jp text-white/80 font-medium leading-[2.2] text-sm lg:text-base mb-10">
              この達成感は、型枠大工にしかわからない。そしてこの瞬間があるから、また次の現場に向かえる。
            </p>
            <Link
              href="/recruit"
              className="inline-flex items-center gap-3 font-sans-jp text-sm tracking-[0.1em] border border-mamitsuka-red text-mamitsuka-red px-8 py-4 hover:bg-mamitsuka-red hover:text-white transition-all duration-300"
            >
              この仕事に挑戦する
              <ArrowRight size={16} />
            </Link>
          </div>
        </SectionWrapper>
      </section>

      {/* FAQ for SEO/LLM */}
      <section className="py-24 lg:py-36">
        <SectionWrapper className="container">
          <div className="max-w-3xl mx-auto">
            <h2 className="font-serif-jp text-2xl lg:text-3xl font-bold mb-12 text-center">
              よくある質問
            </h2>
            <div className="space-y-8">
              {[
                {
                  q: "型枠とは何ですか？",
                  a: "型枠とは、コンクリートを流し込むための「型」のことです。木材や金属パネルを使って建物の壁や柱の形をつくり、コンクリートが固まった後に取り外します。建物の形状と精度を決める、建設工事の中でも最も重要な工程の一つです。",
                },
                {
                  q: "型枠大工とはどんな仕事ですか？",
                  a: "型枠大工は、設計図面を読み解き、型枠の加工・組立・解体を行う専門職人です。1mm単位の精度管理が求められ、建物の品質を左右する重要な役割を担います。在来型枠工法とラス型枠工法の2種類があり、建物の種類や条件に応じて使い分けます。",
                },
                {
                  q: "型枠工事の流れを教えてください。",
                  a: "型枠工事は、①拾い出し（図面から材料を算出）、②加工（部材の切断・組立）、③墨出し（位置の印付け）、④建込み（型枠の組立）、⑤締固め（型枠の固定）、⑥コンクリート打設（流し込み）、⑦脱型（型枠の解体）の順で進みます。",
                },
                {
                  q: "在来型枠とラス型枠の違いは何ですか？",
                  a: "在来型枠は合板パネルを使用する一般的な工法で、平面的な壁や柱に適しています。ラス型枠はメッシュ素材を使用し、材料が非常に軽量で、施工スピードが圧倒的に速いのが特徴です。女性でも簡単に施工でき、狭い場所や型押しの箇所なども在来型枠に比べると施工が容易です。曲面や複雑な形状にも対応しやすく、産業廃棄物の発生を抑え、工期短縮にもつながります。馬見塚建設は両方の工法に対応しています。",
                },
              ].map((faq, i) => (
                <div key={i} className="border-b border-border pb-8 last:border-0">
                  <h3 className="font-serif-jp text-base lg:text-lg font-bold mb-4">{faq.q}</h3>
                  <p className="font-sans-jp text-muted-foreground text-sm leading-[2]">{faq.a}</p>
                </div>
              ))}
            </div>
          </div>
        </SectionWrapper>
      </section>
    </div>
  );
}
