/*
 * Design: Brutalist Cinematic — コンクリートの詩学
 * TOP page: 映画のワンシーンのような世界観。
 * 静かだけど圧倒的な自信。職人の美学。
 */
import { motion } from "framer-motion";
import SectionWrapper from "@/components/SectionWrapper";
import { Link } from "wouter";
import { ArrowRight, ChevronDown } from "lucide-react";

const HERO_IMG = "/manus-storage/hero-new_44467c73.png";
const PRECISION_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/precision-scale-cinematic-LwrPvtZvMdZ4xAFXQuYdpp.webp";
const TEAM_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/team-cinematic-unified_768b6676.png";
const CORE_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/core-platform-future-mjbCwZZAuXeTRsVD2BvFxq.webp";
const RECRUIT_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/recruit-cinematic_eb6ac652.png";

export default function Home() {
  return (
    <div>
      {/* ===== HERO SECTION ===== */}
      <section className="relative h-screen w-full overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <img
            src={HERO_IMG}
            alt="建設現場で図面を確認する職人"
            className="w-full h-full object-cover blur-[1px] scale-[1.01]"
          />
          {/* Cinematic heavy mask: deep vignette + fog layer like original hero */}
          <div className="absolute inset-0 bg-black/40" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/70" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/20 to-black/40" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        </div>

        {/* Hero Content */}
        <div className="relative h-full flex flex-col justify-end pb-20 lg:pb-28 container">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, delay: 0.3, ease: [0.25, 0.1, 0.25, 1] }}
          >
            <p className="font-display text-white/60 text-sm lg:text-base tracking-[0.3em] mb-4 uppercase">
              PRECISION BUILDS THE FUTURE.
            </p>
            <h1 className="font-serif-jp text-white text-3xl sm:text-4xl lg:text-6xl xl:text-7xl font-bold leading-[1.3] lg:leading-[1.2] mb-6">
              街の骨格を、
              <br />
              <span className="text-mamitsuka-red">1mm</span>のズレも許さない。
            </h1>
            <p className="font-sans-jp text-white/70 text-sm lg:text-base max-w-xl leading-relaxed">
              型枠は、建物の形を決める仕事。
              <br />
              職人の思考は、街の未来を決める。
            </p>
          </motion.div>

          {/* Scroll indicator */}
          <motion.div
            className="absolute bottom-8 left-1/2 -translate-x-1/2"
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <ChevronDown className="text-white/40" size={24} />
          </motion.div>
        </div>

        {/* Cinematic letterbox bars */}
        <div className="absolute top-0 left-0 right-0 h-[3vh] bg-black/80" />
        <div className="absolute bottom-0 left-0 right-0 h-[3vh] bg-black/80" />
      </section>

      {/* ===== PHILOSOPHY: 考える職人 ===== */}
      <section className="py-24 lg:py-36">
        <SectionWrapper className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <div>
              <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6">
                Philosophy
              </p>
              <h2 className="font-serif-jp text-3xl lg:text-5xl font-bold leading-[1.4] mb-8">
                建物が建つ前に、
                <br />
                勝負は決まっている。
              </h2>
              <div className="red-thread mb-8" />
              <p className="font-sans-jp text-muted-foreground leading-[2] text-sm lg:text-base mb-8">
                型枠大工の仕事は、コンクリートを流し込む前に始まる。図面を読み、寸法を拾い、段取りを組む。その一つひとつの判断が、建物の精度を決める。足元のズレ、出隅のズレ、垂直のズレ。1mmの狂いも許さない。それが、型枠職人の美学だ。
              </p>
              <Link
                href="/formwork"
                className="inline-flex items-center gap-2 font-sans-jp text-sm tracking-[0.1em] text-mamitsuka-red hover:gap-4 transition-all duration-300"
              >
                型枠という仕事を知る
                <ArrowRight size={16} />
              </Link>
            </div>
            <div className="relative">
              <img
                src={PRECISION_IMG}
                alt="型枠の精度を測る職人の手"
                className="w-full object-cover shadow-2xl"
              />
              <div className="absolute -bottom-4 -right-4 w-24 h-24 border-2 border-mamitsuka-red/20" />
            </div>
          </div>
        </SectionWrapper>
      </section>

      {/* ===== TEAM: 職人チーム ===== */}
      <section className="relative py-24 lg:py-36 bg-mamitsuka-dark overflow-hidden">
        <SectionWrapper className="container relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <div className="order-2 lg:order-1">
              <img
                src={TEAM_IMG}
                alt="型枠を組み上げる若い職人チーム"
                className="w-full object-cover shadow-2xl"
              />
            </div>
            <div className="order-1 lg:order-2">
              <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6">
                Our Team
              </p>
              <h2 className="font-serif-jp text-white text-3xl lg:text-5xl font-bold leading-[1.4] mb-8">
                背中で語る、
                <br />
                若い職人たち。
              </h2>
              <div className="red-thread mb-8" />
              <p className="font-sans-jp text-white/60 leading-[2] text-sm lg:text-base mb-8">
                馬見塚建設の現場には、若い職人たちの熱がある。言葉は少ないが、手は止まらない。阿吽の呼吸で型枠を組み上げ、仲間の背中を信じて現場を動かす。一人の力ではない。チームの力で、街の骨格をつくる。
              </p>
              <Link
                href="/team"
                className="inline-flex items-center gap-2 font-sans-jp text-sm tracking-[0.1em] text-mamitsuka-red hover:gap-4 transition-all duration-300"
              >
                職人チームを見る
                <ArrowRight size={16} />
              </Link>
            </div>
          </div>
        </SectionWrapper>
      </section>

      {/* ===== TRUST: 施工実績 ===== */}
      <section className="py-24 lg:py-36">
        <SectionWrapper className="container">
          <div className="text-center mb-16">
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6">
              Works & Trust
            </p>
            <h2 className="font-serif-jp text-3xl lg:text-5xl font-bold leading-[1.4] mb-6">
              難題こそ、
              <br />
              私たちの日常だ。
            </h2>
            <div className="red-thread mx-auto mb-8" />
            <p className="font-sans-jp text-muted-foreground leading-[2] text-sm lg:text-base max-w-2xl mx-auto">
              マンション、学校、物流施設、商業施設。あらゆる建築物の骨格を、在来型枠とラス型枠の両方で対応する。他社が敬遠する複雑な形状も、精度を出すために現場で考え、段取りし、やり切る。型枠は最後にすべてのズレが出る仕事だからこそ、元請けにとっての「最後の信用」でありたい。
            </p>
          </div>

          {/* Works Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { title: "マンション", desc: "住まいの骨格を、精度で支える。" },
              { title: "学校・公共施設", desc: "子どもたちの未来を、型枠で守る。" },
              { title: "物流・商業施設", desc: "経済の基盤を、現場から創る。" },
            ].map((work, i) => (
              <SectionWrapper key={work.title} delay={i * 0.15}>
                <div className="group relative bg-card border border-border p-8 lg:p-10 hover:border-mamitsuka-red/30 transition-all duration-500">
                  <span className="font-display text-6xl font-bold text-mamitsuka-red/10 absolute top-4 right-6">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <h3 className="font-serif-jp text-xl font-bold mb-4">{work.title}</h3>
                  <p className="font-sans-jp text-muted-foreground text-sm leading-relaxed">
                    {work.desc}
                  </p>
                </div>
              </SectionWrapper>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link
              href="/works"
              className="inline-flex items-center gap-2 font-sans-jp text-sm tracking-[0.1em] text-mamitsuka-red hover:gap-4 transition-all duration-300"
            >
              施工実績を見る
              <ArrowRight size={16} />
            </Link>
          </div>
        </SectionWrapper>
      </section>

      {/* ===== CORE PLATFORM ===== */}
      <section className="relative py-24 lg:py-36 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={CORE_IMG}
            alt="MAMITSUKA CORE PLATFORM"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40" />
        </div>

        <SectionWrapper className="container relative z-10">
          <div className="max-w-2xl">
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6">
              MAMITSUKA CORE PLATFORM
            </p>
            <h2 className="font-serif-jp text-white text-3xl lg:text-5xl font-bold leading-[1.4] mb-8">
              職人の勘を、
              <br />
              世界の共有知へ。
            </h2>
            <div className="red-thread mb-8" />
            <p className="font-sans-jp text-white/70 leading-[2] text-sm lg:text-base mb-4">
              型枠の技術は、図面には書かれていない。現場で積み重ねた判断と感覚がある。
            </p>
            <p className="font-sans-jp text-white/70 leading-[2] text-sm lg:text-base mb-8">
              私たちはその「名もなき経験」をデータ化し、AIと共に次世代へ繋ぐ。施工会社を超え、建設業の未来を創るプラットフォームへ。
            </p>
            <Link
              href="/core-platform"
              className="inline-flex items-center gap-2 font-sans-jp text-sm tracking-[0.1em] text-mamitsuka-red hover:gap-4 transition-all duration-300"
            >
              CORE PLATFORMを知る
              <ArrowRight size={16} />
            </Link>
          </div>
        </SectionWrapper>
      </section>

      {/* ===== RECRUIT ===== */}
      <section className="py-24 lg:py-36">
        <SectionWrapper className="container">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 lg:gap-16 items-center">
            <div className="lg:col-span-2">
              <img
                src={RECRUIT_IMG}
                alt="若い型枠職人"
                className="w-full max-w-sm mx-auto lg:max-w-none object-cover shadow-2xl"
              />
            </div>
            <div className="lg:col-span-3">
              <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6">
                Recruit
              </p>
              <h2 className="font-serif-jp text-3xl lg:text-5xl font-bold leading-[1.4] mb-8">
                最初はできなくて当たり前。
                <br />
                でも、本気なら俺たちが教える。
              </h2>
              <div className="red-thread mb-8" />
              <p className="font-sans-jp text-muted-foreground leading-[2] text-sm lg:text-base mb-4">
                型枠は簡単な仕事ではない。覚えることも多い。でも、一人で放り出す会社ではない。
              </p>
              <p className="font-sans-jp text-muted-foreground leading-[2] text-sm lg:text-base mb-8">
                失敗しながら覚えて、仲間と一緒に精度を出していく。君の技術が、100年後の街の骨格になる。
              </p>
              <Link
                href="/recruit"
                className="inline-flex items-center gap-3 font-sans-jp text-sm tracking-[0.1em] bg-mamitsuka-red text-white px-8 py-4 hover:bg-mamitsuka-red/90 transition-all duration-300"
              >
                採用情報を見る
                <ArrowRight size={16} />
              </Link>
            </div>
          </div>
        </SectionWrapper>
      </section>

      {/* ===== NEWS / BLOG ===== */}
      <section className="py-24 lg:py-36 bg-secondary/50">
        <SectionWrapper className="container">
          <div className="flex items-end justify-between mb-12">
            <div>
              <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-4">
                News & Blog
              </p>
              <h2 className="font-serif-jp text-2xl lg:text-4xl font-bold">
                最新情報
              </h2>
            </div>
            <Link
              href="/blog"
              className="hidden sm:inline-flex items-center gap-2 font-sans-jp text-sm tracking-[0.1em] text-mamitsuka-red hover:gap-4 transition-all duration-300"
            >
              すべて見る
              <ArrowRight size={16} />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                date: "2026.03",
                tag: "note",
                title: "型枠大工はコンクリートを流さない",
                desc: "型枠大工の仕事の本質について、まみ社長が語る。",
                url: "https://note.com/mamitsuka/n/n57683479db70",
              },
              {
                date: "2026.03",
                tag: "YouTube",
                title: "型枠アンセム「FORMED」MV公開",
                desc: "型枠の仕事を音楽で表現したミュージックビデオ。",
                url: "https://www.youtube.com/watch?v=q2JHoIea2Gk",
              },
              {
                date: "2026.02",
                tag: "お知らせ",
                title: "2026年度 新卒採用ページ公開",
                desc: "本気で技術を磨きたい方へ。新卒採用を開始しました。",
                url: "https://www.mamituka.co.jp/katawaku_lp_final.html",
              },
            ].map((news, i) => (
              <SectionWrapper key={i} delay={i * 0.1}>
                <a
                  href={news.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block group"
                >
                  <article className="bg-card border border-border p-6 lg:p-8 hover:border-mamitsuka-red/30 transition-all duration-500 h-full">
                    <div className="flex items-center gap-3 mb-4">
                      <time className="font-display text-xs text-muted-foreground tracking-wider">
                        {news.date}
                      </time>
                      <span className="font-sans-jp text-[10px] tracking-wider px-2 py-0.5 border border-mamitsuka-red/30 text-mamitsuka-red">
                        {news.tag}
                      </span>
                    </div>
                    <h3 className="font-serif-jp text-base font-bold mb-3 group-hover:text-mamitsuka-red transition-colors">
                      {news.title}
                    </h3>
                    <p className="font-sans-jp text-muted-foreground text-sm leading-relaxed">
                      {news.desc}
                    </p>
                  </article>
                </a>
              </SectionWrapper>
            ))}
          </div>
        </SectionWrapper>
      </section>

      {/* ===== 建設業許可情報 ===== */}
      <section className="py-16 lg:py-24 bg-mamitsuka-dark">
        <SectionWrapper className="container">
          <div className="max-w-3xl mx-auto">
            <div className="flex items-center gap-4 mb-8">
              <div className="red-thread" />
              <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase">
                License
              </p>
            </div>
            <h3 className="font-serif-jp text-white text-xl lg:text-2xl font-bold mb-8">
              建設業許可
            </h3>

            <div className="border border-white/10 divide-y divide-white/10">
              <div className="flex flex-col sm:flex-row p-4 lg:p-5">
                <span className="font-sans-jp text-sm font-medium text-white/80 w-48 flex-shrink-0 mb-1 sm:mb-0">
                  事業内容
                </span>
                <span className="font-sans-jp text-sm text-white/50">一般建設業</span>
              </div>
              <div className="flex flex-col sm:flex-row p-4 lg:p-5">
                <span className="font-sans-jp text-sm font-medium text-white/80 w-48 flex-shrink-0 mb-1 sm:mb-0">
                  許可番号
                </span>
                <div className="font-sans-jp text-sm text-white/50 space-y-1">
                  <p>愛知県 知事 許可</p>
                  <p>(般-7) 第32556号</p>
                  <p>(般-17) 第32556号</p>
                  <p>(般-22) 第32556号</p>
                  <p>(般-27) 第32556号</p>
                  <p>(般-2) 第32556号</p>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row p-4 lg:p-5">
                <span className="font-sans-jp text-sm font-medium text-white/80 w-48 flex-shrink-0 mb-1 sm:mb-0">
                  許可年月日
                </span>
                <div className="font-sans-jp text-sm text-white/50 space-y-1">
                  <p>平成17年8月18日</p>
                  <p>平成22年8月17日</p>
                  <p>平成27年8月18日</p>
                  <p>令和2年8月18日</p>
                  <p>令和7年8月18日</p>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row p-4 lg:p-5">
                <span className="font-sans-jp text-sm font-medium text-white/80 w-48 flex-shrink-0 mb-1 sm:mb-0">
                  許可有効期限
                </span>
                <span className="font-sans-jp text-sm text-white/50">令和12年8月17日</span>
              </div>
              <div className="flex flex-col sm:flex-row p-4 lg:p-5">
                <span className="font-sans-jp text-sm font-medium text-white/80 w-48 flex-shrink-0 mb-1 sm:mb-0">
                  許可建設業の種類
                </span>
                <span className="font-sans-jp text-sm text-white/50">建築工事業、大工工事業</span>
              </div>
            </div>
          </div>
        </SectionWrapper>
      </section>
    </div>
  );
}
