/*
 * Design: Brutalist Cinematic — 黒基調 + 赤アクセント
 * Page: まみ社長とは
 * Purpose: 元請け・監督が「この会社に任せたい」と判断する営業ページ
 * SEO: 「まみ社長」「馬見塚建設」「型枠」「ラス型枠」を自然に含める
 * Tone: 現場の人間の言葉。芯のある強さ。信用の積み重ね。
 * Image Rule: 全画像に統一CSSフィルター適用（暗め・低彩度・高コントラスト・暖色）
 */
import { useEffect } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { ArrowRight } from "lucide-react";

/* ── Image URLs ── */
const IMAGES = {
  hero: "https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/president-hero-v3-bFZtDG7GUrJnSAk6RQNUoC.webp",
  portrait: "https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/Gemini_Generated_Image_6fpu7n6fpu7n6fpu_754d29d0.png",
  formwork: "https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/president-formwork-v3-bavqfUqVkivEkZBHR92Qop.webp",
  team: "https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/president-team-v3-QNr99UjKKxoVBzU3cUgkVt.webp",
  philosophy: "https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/president-philosophy-v3-KyQspv4YEdHB8YaaS32J5v.webp",
};

/* ── Unified image filter: dark, desaturated, high-contrast, warm ── */
const IMG_FILTER = "brightness(0.82) saturate(0.85) contrast(1.12) sepia(0.08)";

/* ── Scroll-triggered section ── */
function Section({
  children,
  className = "",
  delay = 0,
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}) {
  const { ref, isVisible } = useScrollAnimation(0.1);
  return (
    <div ref={ref} className={className}>
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={isVisible ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
        transition={{ duration: 1, delay, ease: [0.25, 0.1, 0.25, 1] }}
      >
        {children}
      </motion.div>
    </div>
  );
}

/* ── Horizontal red accent line ── */
function RedThread({ className = "" }: { className?: string }) {
  return <div className={`w-16 h-[2px] bg-mamitsuka-red ${className}`} />;
}

/* ── Label chip ── */
function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-block font-display text-[11px] tracking-[0.3em] uppercase text-mamitsuka-red/80 mb-8">
      {children}
    </span>
  );
}

/* ── Career timeline item ── */
function CareerItem({ age, role }: { age: string; role: string }) {
  return (
    <div className="flex gap-6 items-baseline">
      <span className="font-display text-sm text-mamitsuka-red/70 min-w-[3.5rem] shrink-0">{age}</span>
      <span className="font-sans-jp text-sm text-white/50">{role}</span>
    </div>
  );
}

export default function President() {
  useEffect(() => {
    document.title = "まみ社長とは | 株式会社馬見塚建設 – 型枠工事の信頼と実績";
    const meta = document.querySelector('meta[name="description"]');
    const desc = "まみ社長（馬見塚建設 代表取締役）。1982年生まれ、2代目。現場歴20年以上、職長500現場以上。在来型枠・ラス型枠の両方に対応し、愛知県を拠点にリピート率ほぼ100%の施工実績を持つ型枠会社の経営者。";
    if (meta) {
      meta.setAttribute("content", desc);
    } else {
      const newMeta = document.createElement("meta");
      newMeta.name = "description";
      newMeta.content = desc;
      document.head.appendChild(newMeta);
    }
  }, []);

  return (
    <article className="bg-mamitsuka-dark text-white overflow-hidden">

      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         ① FIRST VIEW — キャッチコピー
         「任せる理由」が一瞬で伝わる
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="relative min-h-screen flex items-end">
        <div className="absolute inset-0">
          <img
            src={IMAGES.hero}
            alt="夜の建設現場 — クレーンとビル群"
            className="w-full h-full object-cover object-center"
            style={{ filter: IMG_FILTER }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-mamitsuka-dark via-mamitsuka-dark/50 to-mamitsuka-dark/20" />
          <div className="absolute inset-0 bg-gradient-to-r from-mamitsuka-dark/80 via-mamitsuka-dark/30 to-transparent" />
        </div>

        <div className="relative container pb-28 lg:pb-36 pt-48">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, delay: 0.3, ease: [0.25, 0.1, 0.25, 1] }}
          >
            <span className="block font-display text-[11px] tracking-[0.35em] uppercase text-white/30 mb-10">
              President
            </span>
            <h1 className="font-serif-jp text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold leading-[1.15] tracking-tight mb-10">
              同じメンバーで、
              <br />
              <span className="text-mamitsuka-red">最後までやり切る</span>
            </h1>
            <div className="max-w-lg">
              <p className="font-sans-jp text-sm sm:text-base text-white/55 leading-[2.2]">
                馬見塚建設は、全員社員で現場に入る
                <br />
                外注に頼らないから、品質がブレない
                <br />
                それが40期続いてきた理由
              </p>
            </div>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-10 left-1/2 -translate-x-1/2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.8 }}
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
            className="w-px h-14 bg-gradient-to-b from-white/30 to-transparent"
          />
        </motion.div>
      </section>

      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         ② TRUST — 外部評価・信頼の証拠（最重要セクション）
         「任せていい会社」と判断させる
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="py-32 lg:py-48">
        <div className="container">
          <Section>
            <SectionLabel>Trust</SectionLabel>
            <h2 className="font-serif-jp text-3xl sm:text-4xl lg:text-5xl font-bold leading-[1.25] mb-16">
              選ばれ続ける、
              <br />
              <span className="text-mamitsuka-red">理由がある</span>
            </h2>
          </Section>

          {/* Trust evidence cards */}
          <Section delay={0.15}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-white/[0.04]">
              <div className="bg-mamitsuka-dark p-10 lg:p-16 border-l-2 border-mamitsuka-red/40">
                <span className="block font-display text-5xl lg:text-6xl font-bold text-mamitsuka-red mb-4">
                  ≒100<span className="text-3xl">%</span>
                </span>
                <h3 className="font-serif-jp text-lg font-bold mb-4">リピート率</h3>
                <p className="font-sans-jp text-sm text-white/45 leading-[2]">
                  一度入った現場から、ほぼ毎回声がかかる
                  <br />
                  社員施工だから品質がブレない
                  <br />
                  外注を入れた時だけ評価が落ちる — それが答え
                </p>
              </div>
              <div className="bg-mamitsuka-dark p-10 lg:p-16 border-l-2 border-mamitsuka-red/40">
                <span className="block font-display text-5xl lg:text-6xl font-bold text-mamitsuka-red mb-4">
                  500<span className="text-3xl">+</span>
                </span>
                <h3 className="font-serif-jp text-lg font-bold mb-4">職長現場数</h3>
                <p className="font-sans-jp text-sm text-white/45 leading-[2]">
                  社長自身が20年以上現場に立ち続けてきた
                  <br />
                  職長として500現場以上を完遂
                  <br />
                  大きなミスは一度もない
                </p>
              </div>
              <div className="bg-mamitsuka-dark p-10 lg:p-16 border-l-2 border-mamitsuka-red/40">
                <span className="block font-display text-5xl lg:text-6xl font-bold text-mamitsuka-red mb-4">
                  40<span className="text-3xl">期</span>
                </span>
                <h3 className="font-serif-jp text-lg font-bold mb-4">事業継続</h3>
                <p className="font-sans-jp text-sm text-white/45 leading-[2]">
                  令和元年に2代目として承継
                  <br />
                  先代から受け継いだ信用を、
                  <br />
                  自分の施工でさらに積み上げてきた
                </p>
              </div>
              <div className="bg-mamitsuka-dark p-10 lg:p-16 border-l-2 border-mamitsuka-red/40">
                <span className="block font-display text-5xl lg:text-6xl font-bold text-mamitsuka-red mb-4">
                  0<span className="text-3xl">回</span>
                </span>
                <h3 className="font-serif-jp text-lg font-bold mb-4">工期遅延</h3>
                <p className="font-sans-jp text-sm text-white/45 leading-[2]">
                  工期は必ず合わせてきた
                  <br />
                  問題が出ても投げない、逃げない
                  <br />
                  最後まで現場にいる会社
                </p>
              </div>
            </div>
          </Section>

          {/* Real voice from the field */}
          <Section delay={0.3}>
            <div className="mt-20 lg:mt-28 max-w-3xl">
              <RedThread className="mb-10" />
              <blockquote className="font-serif-jp text-xl sm:text-2xl lg:text-3xl text-white/70 leading-[1.8] italic">
                「馬見塚さんのところは、
                <br className="hidden sm:block" />
                いつも同じメンバーが来るから安心する」
              </blockquote>
              <p className="font-sans-jp text-sm text-white/30 mt-6">
                — 現場監督からの言葉
              </p>
            </div>
          </Section>
        </div>
      </section>

      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         ③ PORTRAIT + STORY — 社長ストーリー（リアル重視）
         ドラマではなく"信用の積み重ね"として
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="py-32 lg:py-48">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-0 items-start">
            {/* Portrait — 主役画像 */}
            <Section className="lg:col-span-7">
              <div className="relative">
                <img
                  src={IMAGES.portrait}
                  alt="まみ社長 — 株式会社馬見塚建設 代表取締役"
                  className="w-full aspect-[3/2] object-cover object-top"
                  style={{ filter: IMG_FILTER }}
                />
                <div className="absolute -top-4 -left-4 w-20 h-20 border-t-2 border-l-2 border-mamitsuka-red" />
                <div className="absolute -bottom-4 -right-4 w-20 h-20 border-b-2 border-r-2 border-mamitsuka-red" />
              </div>
            </Section>

            {/* Story text */}
            <Section delay={0.2} className="lg:col-span-5 lg:pl-16 xl:pl-24">
              <SectionLabel>Story</SectionLabel>
              <h2 className="font-serif-jp text-3xl sm:text-4xl lg:text-4xl xl:text-5xl font-bold leading-[1.3] mb-10">
                まみ社長
              </h2>
              <RedThread className="mb-10" />

              <dl className="font-sans-jp text-sm text-white/45 leading-loose mb-10 space-y-2">
                <div className="flex gap-6">
                  <dt className="text-white/25 min-w-[5rem] shrink-0">生年</dt>
                  <dd>1982年生まれ</dd>
                </div>
                <div className="flex gap-6">
                  <dt className="text-white/25 min-w-[5rem] shrink-0">役職</dt>
                  <dd>株式会社馬見塚建設 代表取締役（2代目）</dd>
                </div>
                <div className="flex gap-6">
                  <dt className="text-white/25 min-w-[5rem] shrink-0">承継</dt>
                  <dd>令和元年（第40期）</dd>
                </div>
                <div className="flex gap-6">
                  <dt className="text-white/25 min-w-[5rem] shrink-0">現場歴</dt>
                  <dd>20年以上 / 職長500現場以上</dd>
                </div>
                <div className="flex gap-6">
                  <dt className="text-white/25 min-w-[5rem] shrink-0">事業</dt>
                  <dd>型枠工事（在来型枠・ラス型枠）</dd>
                </div>
              </dl>

              <p className="font-sans-jp text-base text-white/60 leading-[2.2]">
                親父の背中を見て、この仕事に入った
                <br />
                監督修行を経て現場を覚え、
                <br />
                勤めていた会社が倒産してからは自社一本
              </p>
              <p className="font-sans-jp text-base text-white/60 leading-[2.2] mt-6">
                朝7時から夜20時まで、厳しい現場を何年もやってきた
                <br />
                仕事がない時期も経験した
                <br />
                それでも投げなかった
              </p>
              <p className="font-sans-jp text-base text-white/60 leading-[2.2] mt-6">
                今も現場に出る
                <br />
                社長が現場を知っている — それが馬見塚建設の強み
              </p>
            </Section>
          </div>
        </div>
      </section>

      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         ④ STRENGTH — 強み（差別化）
         型枠金具のクローズアップ画像を背景に
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="relative py-32 lg:py-48 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={IMAGES.formwork}
            alt="型枠金具のクローズアップ"
            className="w-full h-full object-cover"
            style={{ filter: IMG_FILTER }}
          />
          <div className="absolute inset-0 bg-mamitsuka-dark/88" />
        </div>

        <div className="relative container">
          <Section>
            <SectionLabel>Strength</SectionLabel>
            <h2 className="font-serif-jp text-3xl sm:text-4xl lg:text-5xl font-bold leading-[1.25] mb-16">
              「できない」とは
              <br />
              <span className="text-mamitsuka-red">言わない</span>
            </h2>
          </Section>

          <Section delay={0.15}>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-white/[0.04] mt-4">
              <div className="bg-mamitsuka-dark/90 backdrop-blur-sm p-10 lg:p-14">
                <span className="block font-display text-xs tracking-[0.25em] text-mamitsuka-red/70 uppercase mb-6">01</span>
                <h3 className="font-serif-jp text-xl font-bold mb-5">全員社員施工</h3>
                <p className="font-sans-jp text-sm text-white/40 leading-[2]">
                  毎回同じメンバーで現場に入る
                  <br />
                  顔を知っている人間が来るから、
                  <br />
                  監督のストレスが減る
                </p>
              </div>
              <div className="bg-mamitsuka-dark/90 backdrop-blur-sm p-10 lg:p-14">
                <span className="block font-display text-xs tracking-[0.25em] text-mamitsuka-red/70 uppercase mb-6">02</span>
                <h3 className="font-serif-jp text-xl font-bold mb-5">在来 × ラス</h3>
                <p className="font-sans-jp text-sm text-white/40 leading-[2]">
                  日本でも数少ない、両方に対応できる会社
                  <br />
                  ラス型枠は軽量で施工が速い
                  <br />
                  現場ごとに最適な工法を判断できる
                </p>
              </div>
              <div className="bg-mamitsuka-dark/90 backdrop-blur-sm p-10 lg:p-14">
                <span className="block font-display text-xs tracking-[0.25em] text-mamitsuka-red/70 uppercase mb-6">03</span>
                <h3 className="font-serif-jp text-xl font-bold mb-5">現場がきれい</h3>
                <p className="font-sans-jp text-sm text-white/40 leading-[2]">
                  整理整頓は施工品質に直結する
                  <br />
                  挨拶、姿勢、段取り
                  <br />
                  元請けとの関係性を大事にしている
                </p>
              </div>
            </div>
          </Section>

          <Section delay={0.25}>
            <div className="mt-16 max-w-2xl">
              <p className="font-sans-jp text-base text-white/55 leading-[2.2]">
                難しい現場ほど、考える
                <br />
                「できない」と言う前に、どうやったらできるかを考える
                <br />
                対応力、包容力、発想力 — それが馬見塚建設の現場力
              </p>
            </div>
          </Section>
        </div>
      </section>

      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         ⑤ PHILOSOPHY — 理念と現場での行動
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="relative py-36 lg:py-56 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={IMAGES.philosophy}
            alt="コンクリート躯体 — 型枠の成果"
            className="w-full h-full object-cover"
            style={{ filter: IMG_FILTER }}
          />
          <div className="absolute inset-0 bg-mamitsuka-dark/80" />
          <div className="absolute inset-0 bg-gradient-to-r from-mamitsuka-dark/60 to-transparent" />
        </div>

        <div className="relative container">
          <Section>
            <div className="max-w-2xl">
              <SectionLabel>Philosophy</SectionLabel>
              <h2 className="font-serif-jp text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold leading-[1.2] mb-14">
                出会った人くらいは、
                <br />
                <span className="text-mamitsuka-red">幸せにしてやる</span>
              </h2>
              <RedThread className="mb-14" />
              <p className="font-sans-jp text-lg sm:text-xl text-white/55 leading-[2.4]">
                これが馬見塚建設の理念
              </p>
              <p className="font-sans-jp text-base text-white/45 leading-[2.2] mt-10">
                誠実に対応する、嘘をつかない
                <br />
                監督のストレスを減らす現場をつくる
                <br />
                職人が働きやすい環境を整える
              </p>
              <p className="font-sans-jp text-base text-white/45 leading-[2.2] mt-6">
                言葉ではなく、行動で示してきた
                <br />
                だから次の仕事が来る
              </p>
            </div>
          </Section>
        </div>
      </section>

      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         ⑥ CAREER — 対外活動（信頼の裏付け）
         業界内でも任される存在
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="py-32 lg:py-48">
        <div className="container">
          <Section>
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-0 items-start">
              <div className="lg:col-span-5">
                <SectionLabel>Career</SectionLabel>
                <h2 className="font-serif-jp text-3xl sm:text-4xl lg:text-5xl font-bold leading-[1.25] mb-12">
                  業界でも、
                  <br />
                  <span className="text-mamitsuka-red">任される存在</span>
                </h2>
                <RedThread className="mb-12" />
                <p className="font-sans-jp text-base text-white/50 leading-[2.2]">
                  若手時代から業界内の役職を歴任し、
                  <br />
                  組織運営にも携わってきた
                  <br />
                  同業・元請け双方から信頼を得ている
                </p>
              </div>

              <div className="lg:col-span-7 lg:pl-16 xl:pl-24">
                {/* Timeline */}
                <div className="space-y-8">
                  {/* Group: 若鯱会（初期） */}
                  <div>
                    <p className="font-sans-jp text-xs text-white/25 tracking-wider uppercase mb-4">同業組織</p>
                    <div className="space-y-3 pl-4 border-l border-white/[0.06]">
                      <CareerItem age="26歳" role="若鯱会 副会長就任" />
                      <CareerItem age="27歳" role="若鯱会 会長就任" />
                    </div>
                  </div>

                  {/* Group: モック設立 */}
                  <div>
                    <p className="font-sans-jp text-xs text-white/25 tracking-wider uppercase mb-4">自主組織</p>
                    <div className="space-y-3 pl-4 border-l border-white/[0.06]">
                      <CareerItem age="36歳" role="同業種5社による会「モック」設立" />
                    </div>
                  </div>

                  {/* Group: 元請け関連 */}
                  <div>
                    <p className="font-sans-jp text-xs text-white/25 tracking-wider uppercase mb-4">元請け関連組織</p>
                    <div className="space-y-3 pl-4 border-l border-white/[0.06]">
                      <CareerItem age="39歳" role="高松建設 躯体部会 会長就任" />
                      <CareerItem age="40歳" role="高松建設 高栄会 理事就任" />
                      <CareerItem age="43歳" role="高松建設 高栄会 幹事就任" />
                    </div>
                  </div>

                  {/* Group: 若鯱会（再任） */}
                  <div>
                    <p className="font-sans-jp text-xs text-white/25 tracking-wider uppercase mb-4">再任</p>
                    <div className="space-y-3 pl-4 border-l border-white/[0.06]">
                      <CareerItem age="40歳" role="若鯱会 副会長就任" />
                      <CareerItem age="41歳" role="若鯱会 会長就任" />
                    </div>
                  </div>

                  {/* Group: 協力会 */}
                  <div>
                    <p className="font-sans-jp text-xs text-white/25 tracking-wider uppercase mb-4">協力会</p>
                    <div className="space-y-3 pl-4 border-l border-white/[0.06]">
                      <CareerItem age="" role="松村組 松緑会 理事" />
                      <CareerItem age="" role="石田組 安全協力会 理事" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Section>
        </div>
      </section>

      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         ⑥.5 PEOPLE — 人材育成
         チーム作業風景
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="py-32 lg:py-48">
        <div className="container">
          <Section>
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-0 items-end mb-16 lg:mb-24">
              <div className="lg:col-span-7">
                <SectionLabel>People</SectionLabel>
                <h2 className="font-serif-jp text-3xl sm:text-4xl lg:text-5xl font-bold leading-[1.25]">
                  技術は、
                  <br />
                  <span className="text-mamitsuka-red">人で決まる</span>
                </h2>
              </div>
              <div className="lg:col-span-5 lg:pl-16">
                <RedThread className="mb-8" />
                <p className="font-sans-jp text-base text-white/55 leading-[2.2]">
                  若手中心のチームで、技術を継承している
                  <br />
                  技能実習生も含め、国籍を問わず
                  <br />
                  現場で戦える人材を育てている
                </p>
              </div>
            </div>
          </Section>

          <Section delay={0.15}>
            <div className="relative">
              <img
                src={IMAGES.team}
                alt="馬見塚建設の型枠職人チーム — 倉庫での作業風景"
                className="w-full aspect-[16/9] object-cover"
                style={{ filter: IMG_FILTER }}
              />
              <div className="absolute bottom-0 left-0 w-32 h-[2px] bg-mamitsuka-red" />
            </div>
          </Section>
        </div>
      </section>

      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         ⑥.7 VOICE — 発信
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="py-24 lg:py-36">
        <div className="container">
          <Section>
            <div className="max-w-3xl">
              <SectionLabel>Voice</SectionLabel>
              <h2 className="font-serif-jp text-3xl sm:text-4xl lg:text-5xl font-bold leading-[1.25] mb-12">
                現場の価値を、
                <br />
                <span className="text-mamitsuka-red">外へ</span>
              </h2>
              <RedThread className="mb-12" />
              <p className="font-sans-jp text-base sm:text-lg text-white/55 leading-[2.2]">
                NOTEやSNSを通じて、型枠の仕事や現場のリアルを発信している
                <br />
                AI（かたやん・べに子）も活用しながら、
                <br />
                これからの建設業の在り方を模索している
              </p>
            </div>
          </Section>

          <Section delay={0.2}>
            <div className="flex flex-wrap gap-4 mt-16">
              {[
                { label: "note", href: "https://note.com/mamitsuka" },
                { label: "YouTube", href: "https://www.youtube.com/@kensetu" },
                { label: "Instagram", href: "https://www.instagram.com/mamitsuka_const/" },
                { label: "Facebook", href: "https://www.facebook.com/akinori.mamitsuka/" },
              ].map((sns) => (
                <a
                  key={sns.label}
                  href={sns.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-sans-jp text-xs tracking-[0.15em] border border-white/10 text-white/40 px-7 py-3.5 hover:border-mamitsuka-red hover:text-mamitsuka-red transition-all duration-400"
                >
                  {sns.label}
                </a>
              ))}
            </div>
          </Section>
        </div>
      </section>

      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         ⑦ PROMISE — 元請けへの約束（締め）
         シンプルに強く
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="relative py-36 lg:py-48 overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-px bg-white/[0.04]" />
        <div className="absolute bottom-0 left-0 right-0 h-px bg-white/[0.04]" />

        <div className="container">
          <Section>
            <div className="max-w-3xl mx-auto text-center">
              <SectionLabel>Promise</SectionLabel>
              <h2 className="font-serif-jp text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold leading-[1.25] mb-16">
                元請けへの、
                <span className="text-mamitsuka-red">約束</span>
              </h2>
            </div>
          </Section>

          <Section delay={0.15}>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-px bg-white/[0.04] max-w-5xl mx-auto">
              {[
                { num: "01", text: "同じメンバーで\n現場に入る" },
                { num: "02", text: "最後まで\nやり切る" },
                { num: "03", text: "問題を\n投げない" },
                { num: "04", text: "現場を\nきれいに保つ" },
              ].map((item) => (
                <div key={item.num} className="bg-mamitsuka-dark p-8 lg:p-10 text-center">
                  <span className="block font-display text-xs tracking-[0.25em] text-mamitsuka-red/60 mb-6">
                    {item.num}
                  </span>
                  <p className="font-serif-jp text-base lg:text-lg font-bold leading-[1.8] whitespace-pre-line">
                    {item.text}
                  </p>
                </div>
              ))}
            </div>
          </Section>

          <Section delay={0.3}>
            <div className="max-w-2xl mx-auto text-center mt-20">
              <p className="font-sans-jp text-base text-white/45 leading-[2.2]">
                派手なことは言わない
                <br />
                ただ、任された仕事には必ず応える
                <br />
                それが馬見塚建設のやり方
              </p>
            </div>
          </Section>
        </div>
      </section>

      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         CTA — 導線
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="relative py-28 lg:py-36">
        <div className="absolute top-0 left-0 right-0 h-px bg-white/[0.04]" />

        <div className="container">
          <Section>
            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <Link
                href="/company"
                className="group inline-flex items-center justify-center gap-3 font-sans-jp text-sm tracking-[0.15em] border border-white/15 text-white/80 px-12 py-5 hover:border-mamitsuka-red hover:text-mamitsuka-red transition-all duration-400"
              >
                会社を見る
                <ArrowRight
                  size={16}
                  className="transition-transform duration-300 group-hover:translate-x-1"
                />
              </Link>
              <Link
                href="/recruit"
                className="group inline-flex items-center justify-center gap-3 font-sans-jp text-sm tracking-[0.15em] bg-mamitsuka-red text-white px-12 py-5 hover:bg-[oklch(0.55_0.24_25)] transition-all duration-400"
              >
                採用を見る
                <ArrowRight
                  size={16}
                  className="transition-transform duration-300 group-hover:translate-x-1"
                />
              </Link>
            </div>
          </Section>
        </div>
      </section>
    </article>
  );
}
