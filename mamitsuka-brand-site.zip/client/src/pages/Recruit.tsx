/*
 * Design: Brutalist Cinematic
 * Page: 採用情報 (Recruit)
 * 「最初はできなくて当たり前。でも本気なら俺たちが教える。」
 * 覚悟と安心感の両方を伝える。
 */
import SectionWrapper from "@/components/SectionWrapper";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";

const RECRUIT_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/recruit-cinematic_eb6ac652.png";
const TEAM_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/team-cinematic-unified_768b6676.png";

export default function Recruit() {
  return (
    <div>
      {/* Hero */}
      <section className="relative h-[70vh] lg:h-[80vh] overflow-hidden">
        <div className="absolute inset-0">
          <img src={RECRUIT_IMG} alt="若い型枠職人" className="w-full h-full object-cover object-top" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-black/20" />
        </div>
        <div className="relative h-full flex flex-col justify-end pb-16 lg:pb-24 container">
          <SectionWrapper>
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-4">
              Recruit
            </p>
            <h1 className="font-serif-jp text-white text-3xl lg:text-5xl xl:text-6xl font-bold leading-[1.3]">
              最初はできなくて当たり前。
              <br />
              でも、本気なら
              <br className="sm:hidden" />
              俺たちが教える。
            </h1>
          </SectionWrapper>
        </div>
        <div className="absolute top-0 left-0 right-0 h-[3vh] bg-black/80" />
      </section>

      {/* Message */}
      <section className="py-24 lg:py-36">
        <SectionWrapper className="container">
          <div className="max-w-3xl mx-auto">
            <h2 className="font-serif-jp text-2xl lg:text-4xl font-bold leading-[1.5] mb-8 text-center">
              楽な仕事ではない。
              <br />
              だが、一人にはしない。
            </h2>
            <div className="red-thread mx-auto mb-10" />
            <p className="font-sans-jp text-muted-foreground leading-[2.2] text-sm lg:text-base mb-6">
              型枠は簡単な仕事ではない。覚えることも多い。重い材料を運び、精度を追い込み、天候にも左右される。正直に言えば、楽な仕事ではない。
            </p>
            <p className="font-sans-jp text-muted-foreground leading-[2.2] text-sm lg:text-base mb-6">
              でも、一人で放り出す会社ではない。失敗しながら覚えて、仲間と一緒に精度を出していく。先輩が背中で見せ、言葉で教え、時に厳しく、時に支える。
            </p>
            <p className="font-sans-jp text-foreground font-medium leading-[2.2] text-sm lg:text-base">
              君の成長が、この会社の成長になる。君の技術が、100年後の街の骨格になる。
            </p>
          </div>
        </SectionWrapper>
      </section>

      {/* What You Get */}
      <section className="py-24 lg:py-36 bg-mamitsuka-dark">
        <SectionWrapper className="container">
          <div className="text-center mb-16">
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6">
              What You Get
            </p>
            <h2 className="font-serif-jp text-white text-3xl lg:text-5xl font-bold">
              馬見塚建設で得られるもの。
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                num: "01",
                title: "手に職がつく",
                desc: "型枠大工は国家資格のある専門職。一生食べていける技術が身につく。経験を積めば、どこでも通用する職人になれる。",
              },
              {
                num: "02",
                title: "仲間ができる",
                desc: "型枠は一人ではできない仕事。現場で汗を流した仲間との絆は、一生ものだ。若い職人が多い馬見塚建設だからこそ、同世代の仲間と切磋琢磨できる。",
              },
              {
                num: "03",
                title: "達成感がある",
                desc: "自分が組んだ型枠が、建物の形になる。街を歩けば、自分が関わった建物が見える。これほどわかりやすい達成感は、他にない。",
              },
              {
                num: "04",
                title: "成長できる環境",
                desc: "先輩職人が丁寧に教える。失敗を恐れず挑戦できる環境がある。スキルマップで自分の成長が可視化され、次に何を学べばいいかがわかる。",
              },
              {
                num: "05",
                title: "未来がある",
                desc: "MAMITSUKA CORE PLATFORMの構想に参加できる。型枠の技術を未来に残す、壮大なプロジェクトの一員になれる。",
              },
              {
                num: "06",
                title: "かっこいい",
                desc: "「日本一かっこいい型枠会社」。それは見た目の話ではない。仕事への姿勢、技術へのこだわり、仲間への信頼。その全部がかっこいい。",
              },
            ].map((item, i) => (
              <SectionWrapper key={item.num} delay={i * 0.1}>
                <div className="border border-white/10 p-8 hover:border-mamitsuka-red/30 transition-all duration-500">
                  <span className="font-display text-3xl font-bold text-mamitsuka-red/30 block mb-4">
                    {item.num}
                  </span>
                  <h3 className="font-serif-jp text-white text-lg font-bold mb-4">{item.title}</h3>
                  <p className="font-sans-jp text-white/50 text-sm leading-[2]">{item.desc}</p>
                </div>
              </SectionWrapper>
            ))}
          </div>
        </SectionWrapper>
      </section>

      {/* Team Photo */}
      <section className="relative py-24 lg:py-36 overflow-hidden">
        <div className="absolute inset-0">
          <img src={TEAM_IMG} alt="職人チーム" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-black/60" />
        </div>
        <SectionWrapper className="container relative z-10 text-center">
          <h2 className="font-serif-jp text-white text-3xl lg:text-5xl font-bold leading-[1.4] mb-8">
            覚悟があるなら、
            <br />
            こっちは全力で迎える。
          </h2>
          <div className="red-thread mx-auto mb-8" />
          <p className="font-sans-jp text-white/60 leading-[2] text-sm lg:text-base max-w-xl mx-auto">
            経験は問わない。学歴も問わない。必要なのは、本気で技術を磨きたいという覚悟だけだ。
          </p>
        </SectionWrapper>
      </section>

      {/* Requirements */}
      <section className="py-24 lg:py-36">
        <SectionWrapper className="container">
          <div className="max-w-3xl mx-auto">
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6 text-center">
              Requirements
            </p>
            <h2 className="font-serif-jp text-2xl lg:text-4xl font-bold leading-[1.4] mb-12 text-center">
              募集要項
            </h2>

            <div className="border border-border divide-y divide-border">
              {[
                { label: "職種", value: "型枠大工（見習い〜経験者）" },
                { label: "雇用形態", value: "正社員" },
                { label: "勤務地", value: "愛知県内の各現場（名古屋エリア中心）" },
                { label: "勤務時間", value: "8:00〜17:00（現場による）" },
                { label: "休日", value: "日曜・祝日、GW、夏季休暇、年末年始" },
                { label: "資格", value: "普通自動車免許（AT限定可）" },
                { label: "経験", value: "不問（未経験者歓迎）" },
                { label: "待遇", value: "社会保険完備、資格取得支援、各種手当" },
              ].map((item) => (
                <div key={item.label} className="flex flex-col sm:flex-row p-4 lg:p-6">
                  <span className="font-sans-jp text-sm font-medium w-40 flex-shrink-0 mb-1 sm:mb-0">
                    {item.label}
                  </span>
                  <span className="font-sans-jp text-sm text-muted-foreground">{item.value}</span>
                </div>
              ))}
            </div>
          </div>
        </SectionWrapper>
      </section>

      {/* Final CTA */}
      <section className="py-24 lg:py-36 bg-mamitsuka-dark">
        <SectionWrapper className="container text-center">
          <h2 className="font-serif-jp text-white text-3xl lg:text-5xl font-bold leading-[1.4] mb-8">
            型枠という仕事で、
            <br />
            未来の街をつくろう。
          </h2>
          <div className="red-thread mx-auto mb-8" />
          <p className="font-sans-jp text-white/60 leading-[2] text-sm lg:text-base max-w-xl mx-auto mb-10">
            まずは見学からでも構いません。現場の空気を、自分の目で確かめてください。
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="tel:0561-73-6537"
              className="inline-flex items-center justify-center gap-3 font-sans-jp text-sm tracking-[0.1em] bg-mamitsuka-red text-white px-8 py-4 hover:bg-mamitsuka-red/90 transition-all duration-300"
            >
              電話で問い合わせる
            </a>
            <Link
              href="/company"
              className="inline-flex items-center justify-center gap-3 font-sans-jp text-sm tracking-[0.1em] border border-mamitsuka-red text-mamitsuka-red px-8 py-4 hover:bg-mamitsuka-red hover:text-white transition-all duration-300"
            >
              会社情報を見る
              <ArrowRight size={16} />
            </Link>
          </div>
        </SectionWrapper>
      </section>
    </div>
  );
}
