/*
 * Design: Brutalist Cinematic
 * Page: 職人チーム (Our Team / Craftsmanship)
 * 若い職人チームの雰囲気、チームワーク、現場の空気感を伝える。
 */
import SectionWrapper from "@/components/SectionWrapper";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";

const TEAM_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/team-cinematic-unified_768b6676.png";
const RECRUIT_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/recruit-cinematic_eb6ac652.png";

export default function Team() {
  return (
    <div>
      {/* Hero */}
      <section className="relative h-[60vh] lg:h-[70vh] overflow-hidden">
        <div className="absolute inset-0">
          <img src={TEAM_IMG} alt="職人チーム" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/20 to-black/70" />
        </div>
        <div className="relative h-full flex flex-col justify-end pb-16 lg:pb-24 container">
          <SectionWrapper>
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-4">
              Our Team
            </p>
            <h1 className="font-serif-jp text-white text-3xl lg:text-6xl font-bold leading-[1.3]">
              背中で語る、
              <br />
              若い職人たち。
            </h1>
          </SectionWrapper>
        </div>
        <div className="absolute top-0 left-0 right-0 h-[3vh] bg-black/80" />
      </section>

      {/* Team Philosophy */}
      <section className="py-24 lg:py-36">
        <SectionWrapper className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-serif-jp text-2xl lg:text-4xl font-bold leading-[1.5] mb-8">
              一人の力ではない。
              <br />
              チームの力で、街をつくる。
            </h2>
            <div className="red-thread mx-auto mb-10" />
            <p className="font-sans-jp text-muted-foreground leading-[2.2] text-sm lg:text-base mb-6">
              馬見塚建設の現場には、若い職人たちの熱がある。言葉は少ないが、手は止まらない。阿吽の呼吸で型枠を組み上げ、仲間の背中を信じて現場を動かす。
            </p>
            <p className="font-sans-jp text-muted-foreground leading-[2.2] text-sm lg:text-base">
              型枠は一人ではできない仕事だ。大きなパネルを持ち上げ、位置を合わせ、固定する。その一つひとつの動作に、チームワークが求められる。だからこそ、現場の空気が仕事の質を決める。
            </p>
          </div>
        </SectionWrapper>
      </section>

      {/* Values */}
      <section className="py-24 lg:py-36 bg-mamitsuka-dark">
        <SectionWrapper className="container">
          <div className="text-center mb-16">
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6">
              Our Values
            </p>
            <h2 className="font-serif-jp text-white text-3xl lg:text-5xl font-bold leading-[1.4]">
              私たちが大切にしていること。
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                num: "01",
                title: "精度への執着",
                desc: "1mmの狂いも許さない。それは技術ではなく、姿勢の問題だ。妥協しない職人が、妥協しない建物をつくる。",
              },
              {
                num: "02",
                title: "段取りの文化",
                desc: "手を動かす前に、頭を動かす。図面を読み、工程を組み、材料を準備する。段取りの質が、現場の質を決める。",
              },
              {
                num: "03",
                title: "チームの信頼",
                desc: "型枠は一人ではできない。仲間の技術を信じ、自分の役割を全うする。その信頼関係が、現場を動かす原動力だ。",
              },
              {
                num: "04",
                title: "若さと挑戦",
                desc: "若い職人が多いことは、私たちの強みだ。経験は浅くても、学ぶ意欲と体力がある。毎日が成長の連続だ。",
              },
              {
                num: "05",
                title: "現場の空気",
                desc: "良い現場には、良い空気がある。緊張感と集中力、そして時折の笑い。その空気をつくるのも、職人の仕事だ。",
              },
              {
                num: "06",
                title: "技術の継承",
                desc: "先輩から後輩へ。言葉だけでなく、背中で見せる。型枠の技術は、現場でしか伝わらないものがある。",
              },
            ].map((value, i) => (
              <SectionWrapper key={value.num} delay={i * 0.1}>
                <div className="border border-white/10 p-8 hover:border-mamitsuka-red/30 transition-all duration-500">
                  <span className="font-display text-3xl font-bold text-mamitsuka-red/30 block mb-4">
                    {value.num}
                  </span>
                  <h3 className="font-serif-jp text-white text-lg font-bold mb-4">{value.title}</h3>
                  <p className="font-sans-jp text-white/50 text-sm leading-[2]">{value.desc}</p>
                </div>
              </SectionWrapper>
            ))}
          </div>
        </SectionWrapper>
      </section>

      {/* Day in the Life */}
      <section className="py-24 lg:py-36">
        <SectionWrapper className="container">
          <div className="max-w-3xl mx-auto">
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6 text-center">
              A Day in the Life
            </p>
            <h2 className="font-serif-jp text-2xl lg:text-4xl font-bold leading-[1.4] mb-12 text-center">
              職人の一日。
            </h2>

            <div className="space-y-0">
              {[
                { time: "07:00", title: "現場到着", desc: "朝礼前に図面を確認。今日の段取りを頭の中で組み立てる。" },
                { time: "07:30", title: "朝礼", desc: "安全確認と作業内容の共有。チーム全員で今日のゴールを確認する。" },
                { time: "08:00", title: "作業開始", desc: "墨出し、加工、建込み。集中力を切らさず、精度を追い込む。" },
                { time: "10:00", title: "休憩", desc: "仲間との短い会話。現場の進捗を確認し、午前の後半に備える。" },
                { time: "12:00", title: "昼休憩", desc: "体を休め、午後の段取りを考える。" },
                { time: "13:00", title: "午後の作業", desc: "建込みの続き、精度確認、明日の準備。一日の中で最も集中する時間帯。" },
                { time: "17:00", title: "片付け・終了", desc: "道具を片付け、現場を清掃。明日の段取りを確認して帰路につく。" },
              ].map((item, i) => (
                <div key={i} className="flex gap-6 lg:gap-10">
                  <div className="flex flex-col items-center">
                    <span className="font-display text-sm text-mamitsuka-red font-bold whitespace-nowrap">
                      {item.time}
                    </span>
                    <div className="w-px flex-1 bg-border mt-2" />
                  </div>
                  <div className="pb-10">
                    <h3 className="font-serif-jp text-base font-bold mb-2">{item.title}</h3>
                    <p className="font-sans-jp text-muted-foreground text-sm leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </SectionWrapper>
      </section>

      {/* CTA */}
      <section className="py-24 lg:py-36 bg-secondary/50">
        <SectionWrapper className="container text-center">
          <h2 className="font-serif-jp text-2xl lg:text-4xl font-bold leading-[1.4] mb-6">
            このチームの一員になる。
          </h2>
          <div className="red-thread mx-auto mb-8" />
          <p className="font-sans-jp text-muted-foreground text-sm lg:text-base leading-relaxed max-w-xl mx-auto mb-10">
            経験は問わない。本気で技術を磨きたいなら、私たちが全力で教える。
          </p>
          <Link
            href="/recruit"
            className="inline-flex items-center gap-3 font-sans-jp text-sm tracking-[0.1em] bg-mamitsuka-red text-white px-8 py-4 hover:bg-mamitsuka-red/90 transition-all duration-300"
          >
            採用情報を見る
            <ArrowRight size={16} />
          </Link>
        </SectionWrapper>
      </section>
    </div>
  );
}
