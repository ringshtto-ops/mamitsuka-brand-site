/*
 * Design: Brutalist Cinematic
 * Page: 施工実績 (Works & Trust)
 * 元請けが見たときに「現場力がある会社」と感じる構成。
 * 社長が後から実績を追加できるよう、データ構造を明確にする。
 */
import SectionWrapper from "@/components/SectionWrapper";
import { Link } from "wouter";
import { ArrowRight, Building2, School, Warehouse, Store } from "lucide-react";

const HERO_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/hero-construction-site-n9gqUQyPddN28AGxjbg4Bj.webp";

const categories = [
  { icon: Building2, title: "マンション", desc: "住まいの骨格を、精度で支える。RC造マンションの型枠工事を数多く手がけ、居住者の安全と快適を支えています。" },
  { icon: School, title: "学校・公共施設", desc: "子どもたちの未来を、型枠で守る。学校や公共施設の型枠工事では、特に高い精度と安全性が求められます。" },
  { icon: Warehouse, title: "物流施設", desc: "経済の基盤を、現場から創る。大規模な物流施設の型枠工事では、効率的な段取りと正確な施工が不可欠です。" },
  { icon: Store, title: "商業施設", desc: "街の賑わいを、骨格から支える。商業施設の型枠工事では、複雑な形状への対応力が試されます。" },
];

export default function Works() {
  return (
    <div>
      {/* Hero */}
      <section className="relative h-[60vh] lg:h-[70vh] overflow-hidden">
        <div className="absolute inset-0">
          <img src={HERO_IMG} alt="施工現場" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/70" />
        </div>
        <div className="relative h-full flex flex-col justify-end pb-16 lg:pb-24 container">
          <SectionWrapper>
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-4">
              Works & Trust
            </p>
            <h1 className="font-serif-jp text-white text-3xl lg:text-6xl font-bold leading-[1.3]">
              難題こそ、
              <br />
              私たちの日常だ。
            </h1>
          </SectionWrapper>
        </div>
        <div className="absolute top-0 left-0 right-0 h-[3vh] bg-black/80" />
      </section>

      {/* Trust Statement */}
      <section className="py-24 lg:py-36">
        <SectionWrapper className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-serif-jp text-2xl lg:text-4xl font-bold leading-[1.5] mb-8">
              型枠は、最後にすべてのズレが出る。
              <br />
              だからこそ、「最後の信用」でありたい。
            </h2>
            <div className="red-thread mx-auto mb-10" />
            <p className="font-sans-jp text-muted-foreground leading-[2.2] text-sm lg:text-base mb-6">
              他社が敬遠する複雑な形状や難しい納まりでも、精度を出すために現場で考え、段取りし、やり切る。型枠の精度と段取りで信頼されてきた会社として、元請けにとっての「最後の信用」であり続けます。
            </p>
          </div>
        </SectionWrapper>
      </section>

      {/* Categories */}
      <section className="py-24 lg:py-36 bg-mamitsuka-dark">
        <SectionWrapper className="container">
          <div className="text-center mb-16">
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6">
              Categories
            </p>
            <h2 className="font-serif-jp text-white text-3xl lg:text-5xl font-bold">
              対応分野
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {categories.map((cat, i) => (
              <SectionWrapper key={cat.title} delay={i * 0.1}>
                <div className="border border-white/10 p-8 lg:p-10 hover:border-mamitsuka-red/30 transition-all duration-500 group">
                  <cat.icon className="text-mamitsuka-red mb-6" size={32} strokeWidth={1.5} />
                  <h3 className="font-serif-jp text-white text-xl font-bold mb-4">{cat.title}</h3>
                  <p className="font-sans-jp text-white/50 text-sm leading-[2]">{cat.desc}</p>
                </div>
              </SectionWrapper>
            ))}
          </div>
        </SectionWrapper>
      </section>

      {/* Capabilities */}
      <section className="py-24 lg:py-36">
        <SectionWrapper className="container">
          <div className="text-center mb-16">
            <p className="font-display text-mamitsuka-red text-[13px] font-semibold tracking-[0.3em] uppercase mb-6">
              Capabilities
            </p>
            <h2 className="font-serif-jp text-3xl lg:text-5xl font-bold">
              対応工法
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="border border-border p-8 lg:p-10">
              <h3 className="font-serif-jp text-xl font-bold mb-4">在来型枠工法</h3>
              <div className="red-thread mb-6" />
              <p className="font-sans-jp text-muted-foreground text-sm leading-[2] mb-4">
                合板パネルと桟木を使用する、最も一般的な型枠工法です。壁、柱、梁、スラブなど、あらゆるRC構造物に対応します。
              </p>
              <ul className="space-y-2">
                {["高い汎用性", "コスト効率", "精度管理の実績"].map((item) => (
                  <li key={item} className="font-sans-jp text-sm text-muted-foreground flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-mamitsuka-red rounded-full flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="border border-border p-8 lg:p-10">
              <h3 className="font-serif-jp text-xl font-bold mb-4">ラス型枠工法</h3>
              <div className="red-thread mb-6" />
              <p className="font-sans-jp text-muted-foreground text-sm leading-[2] mb-4">
                メタルラス（金属メッシュ）を使用する工法です。曲面や複雑な形状に対応でき、脱型が不要なため工期短縮にも貢献します。
              </p>
              <ul className="space-y-2">
                {["複雑形状への対応", "脱型不要で工期短縮", "高い施工品質"].map((item) => (
                  <li key={item} className="font-sans-jp text-sm text-muted-foreground flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-mamitsuka-red rounded-full flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </SectionWrapper>
      </section>

      {/* CTA */}
      <section className="py-24 lg:py-36 bg-secondary/50">
        <SectionWrapper className="container text-center">
          <h2 className="font-serif-jp text-2xl lg:text-4xl font-bold leading-[1.4] mb-6">
            お問い合わせ
          </h2>
          <div className="red-thread mx-auto mb-8" />
          <p className="font-sans-jp text-muted-foreground text-sm lg:text-base leading-relaxed max-w-xl mx-auto mb-10">
            型枠工事のご依頼・ご相談は、お気軽にお問い合わせください。
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/company"
              className="inline-flex items-center justify-center gap-3 font-sans-jp text-sm tracking-[0.1em] bg-mamitsuka-red text-white px-8 py-4 hover:bg-mamitsuka-red/90 transition-all duration-300"
            >
              会社情報を見る
              <ArrowRight size={16} />
            </Link>
            <Link
              href="/recruit"
              className="inline-flex items-center justify-center gap-3 font-sans-jp text-sm tracking-[0.1em] border border-mamitsuka-red text-mamitsuka-red px-8 py-4 hover:bg-mamitsuka-red hover:text-white transition-all duration-300"
            >
              採用情報を見る
              <ArrowRight size={16} />
            </Link>
          </div>
        </SectionWrapper>
      </section>
    </div>
  );
}
