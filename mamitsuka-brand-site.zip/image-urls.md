# Image Asset URLs

## Hero (21:9)
- Original: https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/hero-construction-site-GNSGbFecpVTPCwuZzFgesP.png
- Compressed: https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/hero-construction-site-n9gqUQyPddN28AGxjbg4Bj.webp

## Formwork Precision (3:2)
- Original: https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/formwork-precision-oNXnzETj6kqQvUdQnYkNWz.png
- Compressed: https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/formwork-precision-3PdymEj23sQDD4XeZqYaKD.webp

## Team Craftsmen (3:2)
- Original: https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/team-craftsmen-fG3xsdt8LWiFeUXNuRjJnc.png
- Compressed: https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/team-craftsmen-SufxtCK4saB37oxC9uJhyj.webp

## Core Platform Future (16:9)
- Original: https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/core-platform-future-FoFvgC76jJWCHUwoifSU4R.png
- Compressed: https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/core-platform-future-mjbCwZZAuXeTRsVD2BvFxq.webp

## Recruit Young Worker (4:5)
- Original: https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/recruit-young-worker-kjcJFk6dmqtMfG6wavvwn5.png
- Compressed: https://d2xsxph8kpxj0f.cloudfront.net/310519663376354460/FCAeHXUa8a5eBnwJPshg5g/recruit-young-worker-BCnkLDyTQjna2yRstERAuu.webp
