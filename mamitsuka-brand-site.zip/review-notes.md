# Review Notes

## Screenshot 1 - Top Page Hero
- Hero section looks great - cinematic, dramatic
- "街の骨格を、1mmの狂いなく。" copy is impactful
- Navigation items are getting cut off on the right side - need to adjust nav spacing
- "採用情報" link is missing from visible nav - likely hidden behind overflow
- Need to add scroll-to-top on route change
